﻿using Route2NSEx.src.Marquis.systemUtil;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace MarsTestFrame.systemUtil
{
    public class TigerMarsUtil
    {
        private static MLogger Logger = MLogger.GetLogger(typeof(TigerMarsUtil));
        public static string GetPathWithoutFileName(string strFileWithPath)
        {
            Logger.logBegin("GetPathWithoutFileName");
            try
            {
                if (strFileWithPath == null) return null;

                int iLastPos = strFileWithPath.LastIndexOf("\\");
                if (iLastPos == -1)
                {
                    return null;
                }

                return strFileWithPath.Substring(0, iLastPos);

            }
            finally
            {
                Logger.logEnd("GetPathWithoutFileName");

            }
        }

        public static string GetParameter(string strParaName, string strValue)
        {
            return string.Format(" ,[{0}={1}] ", strParaName, strValue);
        }

        public static string GetParameter(string[] arrParaName, string[] strValues)
        {
            string strFormat = "";
            int iMaxLen = arrParaName == null ? -1 : arrParaName.Length;
            iMaxLen = Math.Max(iMaxLen, strValues == null ? -1 : strValues.Length);
            for (int i=0;i<iMaxLen;i++)
            {
                strFormat = string.Format("{0},[{1}={2}]", strFormat, arrParaName[i], strValues[i]);
            }
            return strFormat;
        }

        public static bool RegularTest(string strPartern, string strValue)
        {
            RegexOptions options = RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace ;
            return Regex.IsMatch(strValue, strPartern, options);            
        }

        public static string GetAppRootDir()
        {
            string strDir = Path.GetDirectoryName(typeof(TigerMarsUtil).Assembly.Location);
            strDir = Directory.GetParent(strDir).FullName;

            if (!Directory.Exists(strDir))
                Directory.CreateDirectory(strDir);
            return strDir;
        }

        public static int KillProcessBelong2TargetFold(string strTargetFold)
        {
            Process[] arrProcs = Process.GetProcesses();
            string strP = string.Format(@"^{0}", strTargetFold) ;
            foreach (Process objProc in arrProcs)
            {
                try
                {
                    if (objProc.MainModule == null) continue;
                    if (objProc.MainModule.FileName.StartsWith(strTargetFold))
                    {
                        objProc.Kill();
                    }
                }
                catch (Exception)
                {
                    
                }
                
                
            }
            return 1;
        }

        public static int KillProcessByName(string strAppName)
        {
            Process[] arrProcess = Process.GetProcessesByName(strAppName);
            if (arrProcess == null) return 1;
            for (int i=0 ;i<arrProcess.Length; i++)
            {
                try
                {
                    arrProcess[i].CloseMainWindow();
                }
                catch (Exception e)
                {
                    Logger.Error("KillProcessByName", string.Format("Can't close Mainwindow oft:[{0}]\r\n\tExceptions:[{1}]",strAppName, e.Message),e);
                    try
                    {
                        arrProcess[i].Kill();
                    }
                    catch (Exception ee)
                    {
                        Logger.Error("KillProcessByName", string.Format("Can't Kill process oft:[{0}]\r\n\tExceptions:[{1}]", strAppName, ee.Message), ee);
                        
                    }
                   
                }
                
            }
            return 1;
        }
    }
}
