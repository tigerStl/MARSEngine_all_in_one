﻿/**
 * Record:
 * Date: 20150817
 * Creator:Tiger
 * Version:1.01
 * Description: 
 *   1, new status for RUN column:Exe, done, skip and run
 *   2, Done: when Sucessfully run a test case, when initialized status is run and result is sucessful
 *      Skip: as defined
 *      Run : Initialized value
 *      Exe : Forced to run even the result is failed
 * */


using com.Mars.Constants;
using MarsTestFrame.com.Mars.TestConfigObjects;
using MarsTestFrame.com.Mars.TestConfigObjects.Adatpers;
using MarsTestFrame.CommuniteServer;
using MarsTestFrame.SourceCode.com.Mars.Compiler;
using MarsTestFrame.systemUtil;
using Route2NSEx.src.Marquis.systemUtil;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;

namespace MarsTestFrame.SourceCode.com.Mars.Excels.ConfigurationXls
{
    public delegate ERROR_CODE OnGetCurrentTestCaseByTestSuiteAndTestCaseNameEvent(string strTestSuiteName, string strTestCaseName, TCObjects objTarget);

    public delegate ERROR_CODE OnBeginNavigateTestSuite();
    public delegate ERROR_CODE OnBeginNavigateTestSuiteWithRelyIdAndLoopId(string strRelyId, int iLoop) ;
    public delegate ERROR_CODE OnGetNextTestSuiteEvent(ref TCObjects objTestSuite);
    public delegate ERROR_CODE OnLoadCurrrentTestSuitEvent(); // same as AfterGetNextTestSuiteEvent
    //public delegate ERROR_CODE OnAfterGetNextTestSuiteEvent();
    public delegate ERROR_CODE OnTestsuiteIsDoneEvent(TestSuiteRunStatusInfo objStatus, string strAction = "Run", bool isContinueWhenFalse=false);

    public class BatchXls : MarsExcelFileBase
    {
        #region CONST
        protected const string CNST_EXECUTE_TABLENAME = "Batch";
        const string cnst_SUCCESS = "SUCCESS";
        #endregion

        private static MLogger Logger = MLogger.GetLogger(typeof(BatchXls));

        private List<ConfigObjectBase> mlistTestSuite = new List<ConfigObjectBase>();
        private int miCurrentNavigateId = 0;

        public string CurrentTestProjectName { get; set; } 
        #region for Service
        private TCObjects mobjCurrentTestSuite = null;
        public ERROR_CODE OnGetNextTestSuiteEventImpl(ref TCObjects objTestSuite)
        {
            objTestSuite = getNextTCObject();
            return ERROR_CODE._NO_ERROR;
        }
        public ERROR_CODE OnLoadCurrentTestSuiteEventImpl()
        {
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            if (this.mobjCurrentTestSuite == null)
            {
                eCde = ERROR_CODE._SERVICE_ERROR_CALL_BEGIN_NAVIGATEFIRST_PARA_0;
                return eCde;
            }

            eCde = mobjCurrentTestSuite.loadXlsFile();
            /** compile the objTestSuit **/
            //List<ConfigObjectBase> lstAllSteps = objTestSuit.
            if (eCde != ERROR_CODE._NO_ERROR)
            {
                Logger.Error("OnLoadcurrentTestSuiteEventImpl", string.Format("Error Code ocurrs after call objTestSuit.loadXlsFile() ERROR_CODE:[{0:X}]，ERROR_INFO:[{1}]", eCde, ERROR_INFO.GET_ERROR_STR(eCde)));
                return eCde;
            }
            /*** 加载数据 ***/
            mobjCurrentTestSuite.InitDefaultDataFileName();
            eCde = mobjCurrentTestSuite.loadData();

            return eCde;
        }
        #endregion

        #region Event for Compiler
        private OnCompileListEvent CompileListEventHandler = null;
        public void AddOnCompileListEvent(OnCompileListEvent funcImpl, bool isAdd)
        {
            if (isAdd)
            {
                this.CompileListEventHandler += funcImpl;
            }
            else
            {
                this.CompileListEventHandler -= funcImpl;
            }
        }
        #endregion //Event for Compiler

        protected override ERROR_CODE mAlystExcleFile()
        {
            Logger.logBegin("mAlystExcleFile");

            mlistTestSuite.Clear();

            ERROR_CODE error = this.GetDataTableFromExcelFile();
            if (error != ERROR_CODE._NO_ERROR)
            {
                Logger.Info("mAlystExcleFile", string.Format("GetDataTableFromExcelFile return errorcode[{0:X}]", ERROR_INFO.GET_ERROR_STR(error)));
                return error;
            }

            /**
             * Version 1, 
             *    Only Batch sheet is used
             * */
            int iItm = this.CheckTableExists(string.IsNullOrEmpty(CurrentTestProjectName) ? CNST_EXECUTE_TABLENAME : CurrentTestProjectName);
            if (iItm < 0)
            {
                Logger.Info("mAlystExcleFile", string.Format("CheckTableExists return errorcode[{0:X}], \r\n\terror:[{1}]", ERROR_CODE._BATCH_ERROR_NO_EXECUTE_TABLE, ERROR_INFO.GET_ERROR_STR(ERROR_CODE._BATCH_ERROR_NO_EXECUTE_TABLE)));
                return ERROR_CODE._BATCH_ERROR_NO_EXECUTE_TABLE;
            }
            
            error = this.GetSpecialTableDataToList(this.mlstCurrentTables[iItm], mlistTestSuite);
            if (error != ERROR_CODE._NO_ERROR)
            {
                Logger.Info("mAlystExcleFile", string.Format("GetSpecialTableDataToList return errorcode[{0:X}],\r\n\terror:[{1}]", ERROR_INFO.GET_ERROR_STR(error)));
                return error;
            }

            return ERROR_CODE._NO_ERROR;
        }

        public ERROR_CODE GetCurrentTestCaseByTestSuiteNameAndTestCase(string strTestSuite, string strTestCase, TCObjects objTarget)
        {
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            if (objTarget == null)
            {
                eCde = ERROR_CODE._OBJECT_IS_NULL;
                Logger.Error("GetCurrentTestCaseByTestSuiteNameAndTestCase", "objTarget is Null");
                return eCde;
            }
            string strTestSuiteName = ((BatchConfigObject)mlistTestSuite.ElementAt(miCurrentNavigateId-1)).TCFilePath,
                strTestCaseName = ((BatchConfigObject)mlistTestSuite.ElementAt(miCurrentNavigateId-1)).TCSheetName;
            if (!(string.Compare(strTestSuite, strTestSuiteName, true) == 0) && (string.Compare(strTestCase, strTestCaseName, true) == 0))
            {
                eCde = ERROR_CODE._COMPILER_NOT_THE_CURRENT_TESTCASE_SERVIING_PARA_4;
                Logger.Error("CompilerTestCaseEventImplement", string.Format(ERROR_INFO.GET_ERROR_STR(eCde), strTestSuiteName, strTestCaseName, strTestSuite, strTestCase));
                return eCde;
            }
            objTarget.XlsFileNameWithPath = ((BatchConfigObject)mlistTestSuite.ElementAt(miCurrentNavigateId-1)).TCFilePath;
            objTarget.CurrentRunName = ((BatchConfigObject)mlistTestSuite.ElementAt(miCurrentNavigateId-1)).TCSheetName;
            objTarget.Action4Project = ((BatchConfigObject)mlistTestSuite.ElementAt(miCurrentNavigateId - 1)).Action;
            return eCde;
        }

        public TCObjects getNextTCObject()
        {
            Logger.logBegin("getNextTCObject");
            while ((miCurrentNavigateId < mlistTestSuite.Count) && (miCurrentNavigateId>=0))
            {
                BatchConfigObject objTestSuit = (BatchConfigObject)mlistTestSuite.ElementAt(miCurrentNavigateId);
                if (objTestSuit == null)
                {
                    miCurrentNavigateId++;
                    continue;
                }
                
                if ((string.Compare(objTestSuit.Action, "Run", true) == 0)||(TigerMarsUtil.RegularTest("EXE.*", objTestSuit.Action.ToUpper())))
                {
                    Logger.Info("getNextTCObject", string.Format("trying to get [{0}] parent", objTestSuit.PreParentId??"null"));
                    /** check preconditions **/
                    if (!string.IsNullOrEmpty(objTestSuit.PreParentId))
                    {
                        string[] arrParentId = objTestSuit.PreParentId.Split(new string[]{","},StringSplitOptions.RemoveEmptyEntries);
                        bool isSucessResultOrNull = false ;
                        for (int i = 0; i < arrParentId.Length; i++)
                        {
                            if (string.IsNullOrEmpty(arrParentId[i]) || string.IsNullOrWhiteSpace(arrParentId[i])) continue;
                            /** get the status of the parent status **/
                            //bool isSucessResultOrNullItem = getTSStatusById(objTestSuit.PreParentId);
                            Logger.Info("getNextTCObject", string.Format("Begin to Get RelyId [{0}] status", arrParentId[i]));
                            bool isSucessResultOrNullItem = getTSStatusById(arrParentId[i]);
                            isSucessResultOrNull = isSucessResultOrNullItem;
                            if (!isSucessResultOrNull) break;
                        }
                        if (!isSucessResultOrNull)
                        {
                            miCurrentNavigateId++;
                            continue;
                        }
                    }
                    else
                    {
                        Logger.Info("getNextTCObject", "back to normal ");
                    }

                    TCObjects objTC = new TCObjects();
                    objTC.XlsFileNameWithPath = objTestSuit.TCFilePath;
                    objTC.CurrentRunName = objTestSuit.TCSheetName;
                    objTC.Id4Project = objTestSuit.TestSuiteID;
                    objTC.Action4Project = objTestSuit.Action;

                    miCurrentNavigateId++;
                    return mobjCurrentTestSuite = objTC;
                }
                else
                {
                    miCurrentNavigateId++;
                    continue;
                }
            }
            Logger.logEnd("getNextTCObject");
            return null;
        }

        private bool getTSStatusById(string strId)
        {
            Logger.logBegin("getTSStatusById");
            Logger.Info("getTSStatusById", string.Format("[{0}] count items to be checked", mlistTestSuite.Count));
            for (int i = 0; i < mlistTestSuite.Count;i++ )
            {
                BatchConfigObject objTestSuit = (BatchConfigObject)mlistTestSuite.ElementAt(i);
                Logger.Info("getTSStatusById", string.Format("Current to cmpare TestCase:[id-[{0}]], [test sheetname-{1}],[result -{2}]", objTestSuit.TestSuiteID, objTestSuit.TCSheetName, objTestSuit.RunResult));
                if (string.IsNullOrEmpty(objTestSuit.TestSuiteID)) continue;

                if (string.Compare(strId, objTestSuit.TestSuiteID, true) == 0)
                {
                    if (string.IsNullOrEmpty(objTestSuit.RunResult))
                    {
                        /** the parent test case should be run with success result **/
                        Logger.Error("getTSStatusById", string.Format("RunResult,rely ID is [{0}], [{1}] is not \"Success\".", strId,objTestSuit.RunResult));
                        return false;
                    }

                    if (objTestSuit.RunResult.CompareTo(cnst_SUCCESS) == 0)
                    {
                        return true; 
                    }
                    Logger.Error("getTSStatusById", string.Format("RunResult with rely id [{0}] is not \"Success\", value is [{1}]", strId, objTestSuit.RunResult));
                    return false;
                }
            }
            Logger.Error("getTSStatusById", string.Format("No such rely id [{0}] found", strId));
            Logger.logEnd("getTSStatusById");
            return false;
        }

        protected override ConfigObjectBase mLoadDataRow2ConfigObj(DataRow objRow, int iRowId = -1)
        {
            Logger.logBegin("mLoadDataRow2ConfigObj");
            if (objRow == null) return null;
            TestSuiteAdapter objTestSuiteAdp = TestSuiteAdapterFactory.GetAdapterInstance(MARS_ADAPTER._ADPTR_XLSJET_2_TESTSUITE);
            ConfigObjectBase objResult = objTestSuiteAdp.LoadTestSuiteInfo(objRow);
            Logger.logEnd("mLoadDataRow2ConfigObj");
            return objResult;
        }

        protected void BeginRunTestSuit()
        {
            Logger.logBegin("BeginRunTestSuit");
            /*** Initial a Loop ***/
            miCurrentNavigateId = 0;
            
            Logger.logEnd("BeginRunTestSuit");
        }

        protected ERROR_CODE BeginRunTestSuit(string strRelyId, int iLoopId)
        {
            Logger.logBegin("BeginRunTestSuit");
            miCurrentNavigateId = 0;
            int iLpId = 0;
            while (iLpId< mlistTestSuite.Count)
            {
                //BatchConfigObject objBthObj = (BatchConfigObject)mlistTestSuite.ElementAt(i);
                BatchConfigObject objBthObj = (BatchConfigObject)mlistTestSuite.ElementAt(iLpId);
                if (objBthObj.TestSuiteID.ToUpper().CompareTo(strRelyId==null?"":strRelyId.ToUpper())==0)
                {
                    Logger.Info("BeginRunTestSuit", string.Format("Find special Rely Id and assigned test suite:[{0}]", strRelyId));
                    miCurrentNavigateId = iLpId;
                    return ERROR_CODE._NO_ERROR;
                }
                iLpId++;
            }
            Logger.Info("BeginRunTestSuit", string.Format("can't Find special Rely Id and assigned test suite:[{0}]", strRelyId));
            miCurrentNavigateId = 0;            
            Logger.logEnd("BeginRunTestSuit");
            return ERROR_CODE._BATCH_ERROR_NO_SUCH_RELYID_TESTSUITE_PARA_1;
        }

        protected void EndRuneTestSuit()
        {
            Logger.logBegin("EndRuneTestSuit");
            miCurrentNavigateId = -1;
            Logger.logEnd("EndRuneTestSuit");
            //throw new NotImplementedException();
        }

        public ERROR_CODE OnNavigateHandlerImpl()
        {
            this.BeginRunTestSuit();
            return ERROR_CODE._NO_ERROR;
        }

        public ERROR_CODE OnNavigateWithRelyIdAndLoopIdHandlerImpl(string strRelyId, int iLoop)
        {
            return this.BeginRunTestSuit(strRelyId, iLoop);
        }

        internal ERROR_CODE OnTestSuiteIsDoneEventImpl(TestSuiteRunStatusInfo objStatus, string strAction = "Run",bool isContinueWhenFalse=true)
        {
            /** write a statu string back to Batch file **/
            //const string cnst_update_singlecell = "update [{0}$] set RESULT='[{2}]', ERROR_CAUSE='{3}', SCRIPT_START='[{4}]', SCRIPT_END='[{5}]' where RELY='{1}'";
            const string cnst_update_singlecell = "update [{0}$] set F5='[{2}]', F6='{3}', F7='[{4}]', F8='[{5}]' where F2='{1}'";
            const string cnst_update_singlecell_ex = "update [{0}$] set F5='[{2}]', F6='{3}', F7='[{4}]', F8='[{5}]', F1='{6}' where F2='{1}'";
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            if (mobjCurrentTestSuite==null) return eCde ;

            string strTestSuiteName = mobjCurrentTestSuite.XlsFileNameWithPath, 
                strTestCaseName=mobjCurrentTestSuite.CurrentRunName ;

            string iCurrentId = ((BatchConfigObject)this.mlistTestSuite[(this.miCurrentNavigateId-1)>0?this.miCurrentNavigateId-1:0]).TestSuiteID;
            
            bool isSuccess = false ;
            if (!(isSuccess = !(string.Compare(cnst_SUCCESS, objStatus.RunResult, true) != 0)))
            {
                Logger.Error("OnTestSuiteIsDoneEventImpl", string.Format("Result from Client is [{0}], Test Ends.", objStatus.RunResult));
                if (!isContinueWhenFalse)
                    EndRuneTestSuit();
            }
                

            GetWritableConnectionWithoutHead();
            string strReason = string.IsNullOrEmpty(objStatus.CauseReason) ? "" : objStatus.CauseReason.Replace("'", "''");
            string strUpdate = "", strNewAction=null;
            /** comment for version 1.1 
            * 1, if the initialiaztion action is run, then action changes to  done if isSuccess = true, else, no change
            * 2, if the initialiaztion action is exe then, only change result 
            * **/
            if (string.Compare("Run", strAction, true) == 0)
            {
                if (isSuccess)
                {
                    strNewAction = "Done";
                    strUpdate = string.Format(cnst_update_singlecell_ex, string.IsNullOrEmpty(CurrentTestProjectName) ? CNST_EXECUTE_TABLENAME : CurrentTestProjectName, iCurrentId, objStatus.RunResult, strReason, objStatus.StartTime, objStatus.EndTime, strNewAction);
                }
                else
                    strUpdate = string.Format(cnst_update_singlecell, string.IsNullOrEmpty(CurrentTestProjectName) ? CNST_EXECUTE_TABLENAME : CurrentTestProjectName, iCurrentId, objStatus.RunResult, strReason, objStatus.StartTime, objStatus.EndTime);
            }else
            {
                strUpdate = string.Format(cnst_update_singlecell, string.IsNullOrEmpty(CurrentTestProjectName) ? CNST_EXECUTE_TABLENAME : CurrentTestProjectName, iCurrentId, objStatus.RunResult, strReason, objStatus.StartTime, objStatus.EndTime);
            }
                
            Logger.Info("OnTestSuiteIsDoneEventImpl", string.Format("UPdateSQL: [{0}]", strUpdate));
            eCde =this.RunNoneQuerySql(strUpdate);

            /** update catch **/
            if (eCde == ERROR_CODE._NO_ERROR)
            {
                Logger.Info("----updateTestSuiteStatusCatch----", string.Format("parameters:{0}, {1}", iCurrentId, objStatus.RunResult));
                updateTestSuiteStatusCatch(iCurrentId, objStatus.RunResult, strNewAction);
            }
            else
            {
                Logger.Error("OnTestSuiteIsDoneEventImpl", string.Format("Returned value after calling RunNoneQuerySql is [{0}]", eCde));
            }
            this.RecoveryReadConnection();
            return eCde;                   
        }

        private void updateTestSuiteStatusCatch(string iCurrentId, string strResult, string strNewAction)
        {
            Logger.logBegin("updateTestSuiteStatusCatch");
            for (int i = 0; i < this.mlistTestSuite.Count; i++)
            {
                BatchConfigObject objBthObj = (BatchConfigObject)mlistTestSuite.ElementAt(i);
                if (string.Compare(objBthObj.TestSuiteID, iCurrentId, true) == 0)
                {
                    objBthObj.RunResult = strResult;
                    if (strNewAction!=null)
                    {
                        objBthObj.Action = strNewAction;
                    }
                    Logger.Info("updateTestSuiteStatusCatch" ,string.Format("Changed object relyid=[{0}] catch to [{1}] ", iCurrentId, strResult));
                    return;
                }
            }
            Logger.logEnd("updateTestSuiteStatusCatch");
        }

        
    }
}
