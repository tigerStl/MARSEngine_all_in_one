﻿using com.Mars.Constants;
using MarsTestFrame.SourceCode.systemUtil;
using Route2NSEx.src.Marquis.systemUtil;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace MarsTestFrame.SourceCode.com.Mars.QTP
{
    public class QTPManagement
    {
        private static MLogger Logger = MLogger.GetLogger(typeof(QTPManagement));
#if _tigerQTPHost
        public QuickTest.Application gApp = new QuickTest.Application();
        protected QuickTest.Action mobjCurrentAction = null;

        public Thread mobjThreadHost = null;
        public ERROR_CODE CreateAQtpTest(StringBuilder strRunnableScript)
        {
            /*
            QuickTest.Action objAction = gApp.Test.AddNewAction("tigerAction1", "", "", false,QuickTest.qtActionPosition.qtAtBegining);
            objAction.SetScript(strRunnableScript.ToString());
            gApp.Test.RunAction("tigerAction1");
             * reuse the first action
             */
            Logger.logBegin("CreateAQtpTest");

            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            try
            {
                QuickTest.Action objAction = null;

                eCde = RefreshQTP();

                if (gApp.Test.Actions.Count > 0)
                    foreach (QuickTest.Action oA in gApp.Test.Actions)
                    {
                        objAction = oA;
                        break;
                    }
                else
                    objAction = gApp.Test.AddNewAction("tigerAction1", "", "", false, QuickTest.qtActionPosition.qtAtBegining);
                string strValidateStr = objAction.ValidateScript(strRunnableScript.ToString());
                if (strValidateStr != "")
                {
                    eCde = ERROR_CODE._QTP_ERROR_VALIDATE;
                    Logger.Error("CreateAQtpTest", string.Format(ERROR_INFO.GET_ERROR_STR(eCde), strValidateStr));
                    return eCde;
                }
                objAction.SetScript(strRunnableScript.ToString());
                //string strScrpt = objAction.GetScript();
                gApp.Test.Run();
            }
            catch (Exception e)
            {
                eCde = ERROR_CODE._QTP_ERROR_GENERAL;
                Logger.Error("CreateAQtpTest", string.Format(ERROR_INFO.GET_ERROR_STR(eCde), e.Message), e);
                throw new MarsExceptions((int)eCde, string.Format(ERROR_INFO.GET_ERROR_STR(eCde), e.Message));
            }
            Logger.logEnd("CreateAQtpTest");
            return ERROR_CODE._NO_ERROR;
        }

        /*** Create a empty Test ***/
        public ERROR_CODE CreateAQtpTest(List<string> lstLibrariesName, List<string> lstAddins)
        {
            Logger.logBegin("CreateAQtpTest");
            try
            {
                ERROR_CODE eCde = RefreshQTP();
                if (eCde != ERROR_CODE._NO_ERROR)
                {
                    return eCde;
                }

                if (gApp.Test.Actions.Count > 0)
                {
                    foreach (QuickTest.Action oA in gApp.Test.Actions)
                    {
                        this.mobjCurrentAction = oA;
                        break;
                    }
                }
                else
                {
                    this.mobjCurrentAction = gApp.Test.AddNewAction("TigerMarsTSAction", MarsTestFrame.Properties.Resources.HINT_TEST_ACTION_DEFAULT_DESCRIPTION, "", false, QuickTest.qtActionPosition.qtAtBegining);
                }

                /** Add Libraries **/
                QuickTest.TestLibraries oITestLib = gApp.Test.Settings.Resources.Libraries;
                foreach (string strLibName in lstLibrariesName)
                {
                    oITestLib.Add(strLibName);
                }
                try
                {
                    /** Add Addins   **/
                    object[] arrAddins = lstAddins.ToArray();
                    //object[] arrDescription = new string[lstAddins.Count] ;
                    object objDes = null;
                    object objAddins = arrAddins;
                    gApp.Test.SetAssociatedAddins(ref objAddins, out objDes);
                    return ERROR_CODE._NO_ERROR;
                }
                catch (Exception e)
                {
                    Logger.Error("CreateAQtpTest with lst parameters", string.Format(ERROR_INFO.GET_ERROR_STR(ERROR_CODE._QTP_ERROR_SETTINGADDINS), e.Message));
                    return ERROR_CODE._QTP_ERROR_SETTINGADDINS;
                }
                finally
                {
                    Logger.logEnd("CreateAQtpTest with lst parameters");
                }

            }
            catch (Exception e)
            {
                Logger.Error("CreateAQtpTest", string.Format(ERROR_INFO.GET_ERROR_STR(ERROR_CODE._QTP_ERROR_CREATE_EMPTYTEST), e.Message), e);
                return ERROR_CODE._QTP_ERROR_CREATE_EMPTYTEST;
            }
            finally
            {
                Logger.logEnd("CreateAQtpTest");
            }

        }

        private ERROR_CODE RefreshQTP()
        {
            Logger.logBegin("RefreshQTP");
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            try
            {
                if (!gApp.Launched)
                {
                    gApp.Launch();
                }
                gApp.New(false);
#if _tigerDebug
                gApp.Visible = true;
#endif
                return eCde;
            }
            catch (Exception e)
            {
                eCde = ERROR_CODE._QTP_ERROR_REFRESH;
                Logger.Error("RefreshQTP", string.Format(ERROR_INFO.GET_ERROR_STR(eCde), e.Message), e);
                throw new MarsExceptions((int)eCde, string.Format(ERROR_INFO.GET_ERROR_STR(eCde), e.Message));
            }
            finally
            {
                Logger.logEnd("RefreshQTP");
            }
        }

        public ERROR_CODE TestQTPTestAddins(StringBuilder strRunnableScript)
        {
            Logger.logBegin("TestQTPTestAddins");

            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            try
            {
                eCde = RefreshQTP();
                gApp.Open(@"C:\Downloads\testCase\DebugMode");
                dynamic obj = gApp.Test.GetAssociatedAddins();
                Logger.Info("TestQTPTestAddins", obj);



            }
            catch (Exception e)
            {
                eCde = ERROR_CODE._QTP_ERROR_GENERAL;
                Logger.Error("TestQTPTestAddins", string.Format(ERROR_INFO.GET_ERROR_STR(eCde), e.Message), e);
                throw new MarsExceptions((int)eCde, string.Format(ERROR_INFO.GET_ERROR_STR(eCde), e.Message));
            }
            Logger.logEnd("TestQTPTestAddins");
            return ERROR_CODE._NO_ERROR;
        }
#if _tigerDebug
        public ERROR_CODE TestQTPTestSetAddins(List<string> lstAddins)
        {
            Logger.logBegin("TestQTPTestAddins");

            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            try
            {
                eCde = RefreshQTP();
                gApp.Open(@"C:\work\marquis\AutomationTest\APItest\GUITest1");
                gApp.Visible = true;
                //dynamic obj = gApp.Test.GetAssociatedAddins();
                object[] arrlstAddins = lstAddins.ToArray();
                object objAddins = arrlstAddins;
                object objOutErrorDescription;
                gApp.Test.SetAssociatedAddins(ref objAddins, out objOutErrorDescription);



            }
            catch (Exception e)
            {
                eCde = ERROR_CODE._QTP_ERROR_GENERAL;
                Logger.Error("TestQTPTestAddins", string.Format(ERROR_INFO.GET_ERROR_STR(eCde), e.Message), e);
                throw new MarsExceptions((int)eCde, string.Format(ERROR_INFO.GET_ERROR_STR(eCde), e.Message));
            }
            Logger.logEnd("TestQTPTestAddins");
            return ERROR_CODE._NO_ERROR;
        }
#endif


        internal ERROR_CODE InsertRunnableTestScript(StringBuilder strRunnableScript)
        {
            Logger.logBegin("InsertRunnableTestScript");
            this.mobjCurrentAction.SetScript(strRunnableScript.ToString());
            this.mobjCurrentAction.Type = "Reusable";
            Logger.logEnd("InsertRunnableTestScript");
            return ERROR_CODE._NO_ERROR;
        }

        internal ERROR_CODE RunTest()
        {
            Logger.logBegin("RunTest");

            //this.gApp.Test.Run();
            
            /** Dead Lock problems **/            
            
            QtpThreadHost objHost = new QtpThreadHost();
            objHost.mobjApp = this.gApp ;
            mobjThreadHost = new Thread(new ThreadStart(objHost.RunUFT));
            mobjThreadHost.Start();
            
            //mobjThreadHost.Join();
            //Thread.Sleep(100000);
            Logger.logEnd("RunTest");
            return ERROR_CODE._NO_ERROR;
        }    
        
    }

    class QtpThreadHost
    {
        internal QuickTest.Application mobjApp;
        public void RunUFT()
        {
            //QTPManagement.gApp.Test.Run(null, true, null);
            /** 
             * qtTest.Settings.Run.OnError = "NextStep" ' Instruct UFT to perform next step when error occurs

Set qtResultsOpt = CreateObject("QuickTest.RunResultsOptions") ' Create the Run Results Options object
qtResultsOpt.ResultsLocation = "C:\Tests\Test1\Res1" ' Set the results location

' Set options for automatic export of run results at the end of every run session

Set qtAutoExportResultsOpts = qtApp.Options.Run.AutoExportReportConfig
qtAutoExportResultsOpts.AutoExportResults = True ' Instruct UFT to automatically export the run results at the end of each run session
qtAutoExportResultsOpts.StepDetailsReport = True ' Instruct UFT to automatically export the step details part of the run results at the end of each run session
qtAutoExportResultsOpts.DataTableReport = True ' Instruct UFT to automatically export the data table part of the run results at the end of each run session
qtAutoExportResultsOpts.LogTrackingReport = True ' Instruct UFT to automatically export the log tracking part of the run results at the end of each run session
qtAutoExportResultsOpts.ScreenRecorderReport = True ' Instruct UFT to automatically export the screen recorder part of the run results at the end of each run session
qtAutoExportResultsOpts.SystemMonitorReport = False ' Instruct UFT not to automatically export the system monitor part of the run results at the end of each run session
qtAutoExportResultsOpts.ExportLocation = "C:\Documents and Settings\All Users\Desktop" 'Instruct UFT to automatically export the run results to the Desktop at the end of each run session
qtAutoExportResultsOpts.UserDefinedXSL = "C:\Documents and Settings\All Users\Desktop\MyCustXSL.xsl" ' Specify the customized XSL file when exporting the run results data
qtAutoExportResultsOpts.StepDetailsReportFormat = "UserDefined" ' Instruct UFT to use a customized XSL file when exporting the run results data
qtAutoExportResultsOpts.ExportForFailedRunsOnly = True ' Instruct UFT to automatically export run results only for failed runs
*/
            //QuickTest.RunResultsOptions objResult = new QuickTest.RunResultsOptions();
            

            mobjApp.Test.Run();
            Thread.Sleep(10000);
        }
#endif
    }
}
