﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using log4net;

using com.Mars.Constants;
using Route2NSEx.src.Marquis.systemUtil;
using MarsTestFrame.SourceCode.com.Mars.Excels.ConfigurationXls;
using MarsTestFrame.SourceCode.com.Mars.Compiler;
using MarsTestFrame.SourceCode.systemUtil;
using com.Mars.Config;
using MarsTestFrame.com.Mars.TestConfigObjects;
using MarsTestFrame.SourceCode.com.Mars.TCDataSource;
using MarsTestFrame.CommuniteServer;
using System.Threading;
using System.Diagnostics;
using System.Data.OleDb;

namespace com.Mars.MarsTestingFrame
{
    public class MarsTestFrameMain
    {
        private static MLogger Logger = MLogger.GetLogger(typeof(MarsTestFrameMain));
        private BatchXls mobjXlsBatch = new BatchXls();
        private TestCaseCompilerMainEntry mobjCompiler = new TestCaseCompilerMainEntry();
        private MarsTestFrameCommuniteServer mobjFrameworkService = new MarsTestFrameCommuniteServer();

        private string mstrCurrentBatchFileName = null;
        private ERROR_CODE meCdeCurrentServerError =ERROR_CODE._NO_ERROR ;
        private Thread mobjThreadHost = null;

        public string CurrentTestProjectName { get;set;}
        public string CurrentTestApplicationShortName { get; set; }

        #region Debug information
        private string mstrDebugModeInfo = SystemConstant.CNST_APPCONFIG_APPSETTING_DEBUGMODE_NONE; //default value
        #endregion //Debug

        public ERROR_CODE RunTestBatchFileByThread(string strFileNameWithPath, FrameWorkStartMode startMode = FrameWorkStartMode.FWSM_Normal )
        {
           
            
            mstrCurrentBatchFileName = strFileNameWithPath;
            this.StartBatchFile(startMode);
            /*mobjThreadHost = new Thread(new ThreadStart(this.StartBatchFile));
            mobjThreadHost.Start();
             * */
            return meCdeCurrentServerError;
        }

        private void StartBatchFile(FrameWorkStartMode startMode = FrameWorkStartMode.FWSM_Normal)
        {
            meCdeCurrentServerError = RunTestBatchFile(startMode);
        }

        /***
         * This is the main entry for testframe work
         * */
        private ERROR_CODE RunTestBatchFile(FrameWorkStartMode startMode = FrameWorkStartMode.FWSM_Normal)
        {

            Logger.logBegin("RunTestBatchFile");
            string strFileNameWithPath = this.mstrCurrentBatchFileName;

            /**
             * Steps:
             * 1, Open BatchQtp.xls
             * 2, Read Runnable items
             */
            mobjXlsBatch.XlsFileNameWithPath = strFileNameWithPath;
            mobjXlsBatch.CurrentTestProjectName = this.CurrentTestProjectName;
            ERROR_CODE eCode = mobjXlsBatch.loadXlsFile();            
            if (eCode!=ERROR_CODE._NO_ERROR)
            {
                Logger.Error("RunTestBatchFile", string.Format("Finished Load Test suites, but Errors come, error code[{0:X}], error:[{1}]", eCode,ERROR_INFO.GET_ERROR_STR(eCode)));
                return eCode;
            }
            
            this.mstrDebugModeInfo = AppConfigReader.GetDebugModeInfo();
            this.mstrDebugModeInfo = this.mstrDebugModeInfo ?? SystemConstant.CNST_APPCONFIG_APPSETTING_DEBUGMODE_NONE;            

            /*** get each test suite and run it ***/
            /*mobjXlsBatch.BeginRunTestSuit();
            TCObjects objTestSuit = mobjXlsBatch.getNextTCObject() ;
            int iErrorStep = 0;
            TestStep objErrorStep=null ;
            string strCurrentError = "";
            */
            this.mobjFrameworkService.CurrentTestApplicationShortName = this.CurrentTestApplicationShortName;
            /*** Init all delegate ***/
            this.mobjFrameworkService.AddGetCurrentTestCaseByTSAndTCEventHandler(mobjXlsBatch.GetCurrentTestCaseByTestSuiteNameAndTestCase, true);
            this.mobjFrameworkService.AddOnNavigateHandler(mobjXlsBatch.OnNavigateHandlerImpl, true);
            this.mobjFrameworkService.AddOnBeginNavigateTestSuiteWithRelyIdAndLoopIdHandler(mobjXlsBatch.OnNavigateWithRelyIdAndLoopIdHandlerImpl, true);
            this.mobjFrameworkService.AddOnGetNextTestSuiteEvent(mobjXlsBatch.OnGetNextTestSuiteEventImpl, true);
            this.mobjFrameworkService.AddOnLoadcurrentTestSuiteEvent(mobjXlsBatch.OnLoadCurrentTestSuiteEventImpl, true);
            this.mobjFrameworkService.AddOnTestSuiteIsDoneEventHandler(mobjXlsBatch.OnTestSuiteIsDoneEventImpl, true);
            this.mobjFrameworkService.AddOnCompileListEventHandler(mobjCompiler.preComplierTestSteps, true);
            
            /*** start service ***/
            string strServiceURL = AppConfigReader.GetConfigServerURLInfo();
            eCode = this.mobjFrameworkService.StartService(strServiceURL);
            if (eCode != ERROR_CODE._NO_ERROR)
            {
                Logger.Error("RunTestBatchFile", MarsTestFrame.Properties.Resources.HINT_CANT_START_FRAMEWORK_SERVICE);
                MessageBox.Show(MarsTestFrame.Properties.Resources.HINT_CANT_START_FRAMEWORK_SERVICE, "ERROR");
                return eCode;
            }
#if !_tigerQTPHost
            if ((startMode & FrameWorkStartMode.FWSM_Slience) != FrameWorkStartMode.FWSM_Slience)
            {
                Process objNewMonitor = new Process { StartInfo = new ProcessStartInfo { FileName = @".\TestFrameMonitor.exe" } };
                objNewMonitor.Start();
                Process objNewProce = new Process { StartInfo = new ProcessStartInfo { FileName = @".\QtpStarter.exe" } };
                objNewProce.Start();
            }
#endif
            /*

            while (objTestSuit != null)
            {
                eCode = objTestSuit.loadXlsFile();
                /** compile the objTestSuit ** /
                //List<ConfigObjectBase> lstAllSteps = objTestSuit.
                if (eCode != ERROR_CODE._NO_ERROR)
                {
                    Logger.Error("RunTestBatchFile", string.Format("Error Code ocurrs after call objTestSuit.loadXlsFile() ERROR_CODE:[{0:X}]，ERROR_INFO:[{1}]",eCode,ERROR_INFO.GET_ERROR_STR(eCode)));
                    return eCode;
                }
                /*** 加载数据 *** /
                objTestSuit.InitDefaultDataFileName();
                eCode = objTestSuit.loadData();           

                eCode = mobjCompiler.preComplierTestSteps(objTestSuit.CurrentStepsList,ref iErrorStep, ref objErrorStep,ref strCurrentError);
                if (eCode!=ERROR_CODE._NO_ERROR)
                {
                    MessageBox.Show("Compiler Error, please check LogFile", "Error");
                    break;
                }            
                
                /*** put list to WCF server *** /
                this.mobjFrameworkService.SetCurrentTestSuiteObject(objTestSuit);
                this.mobjFrameworkService.InitListTestSteps(objTestSuit.CurrentStepsList);
                this.mobjFrameworkService.SetCurrentErrorInfo(iErrorStep, strCurrentError,objErrorStep);
#if _tigerDebugSaveData
                this.mobjFrameworkService.StoreDataBackComparisonMode("TC_FO_LOGON.xls", "[StorageMode:Comparing;ColIndx:2;ConvertMethod:NONE];TRADE_PAY_NTL", "10M", 1);
#endif
                /*** start service as Thread*** /
#if _tigerQTPHost
               
#endif
#if !_tigerQTPHost
                
                if (string.Compare(this.mstrDebugModeInfo, SystemConstant.CNST_APPCONFIG_APPSETTING_DEBUGMODE_VBS, true) == 0)
                {
                    MessageBox.Show("Debug Mode, Wait....\r\nClose the dialog, and Services will stop.");
                    objTestSuit = mobjXlsBatch.getNextTCObject();
                }
                else
                {
                    //create a process and wait 
                    Process objNewProce = new Process { StartInfo = new ProcessStartInfo { FileName = @".\QtpStarter.exe" } };                
                    objNewProce.Start();
                    objNewProce.WaitForExit();
                    objTestSuit = mobjXlsBatch.getNextTCObject();
                }                
#endif                
            }
            mobjXlsBatch.EndRuneTestSuit();        
     
            if (eCode!=ERROR_CODE._NO_ERROR)
            {
                return eCode;
            }

            /** get data parameter and concat all script files for qtp running ** /            
             
             */
            return eCode;
        }

#if _tigerQTPHost
        private ERROR_CODE BuildRunningScript(List<ConfigObjectBase> lstSteps, ref int iErrorStep, ref TestStep objStep)
        {
            Logger.logBegin("BuildRunningScript");
            StringBuilder strRunnableScript = new StringBuilder();
            ERROR_CODE eCde = GenerateAllRequiredKeywordsDefs(lstSteps,ref strRunnableScript, ref iErrorStep, ref objStep);
            strRunnableScript.Clear();
            strRunnableScript.Append("\r\n ");
            //strRunnableScript.Append(MarsTestFrame.Properties.Resources.HINT_RUNABLESCRIPT_STARTER_MARK);

            strRunnableScript.Append("call RunTestFrameWork()\r\n");
            strRunnableScript.Append("msgbox \"ok\"\r\n"); 

            eCde = RunGeneratedScript(strRunnableScript);
            Logger.logEnd("BuildRunningScript");
            return ERROR_CODE._NO_ERROR;
        }

        private ERROR_CODE RunGeneratedScript(StringBuilder strRunnableScript)
        {
            Logger.logBegin("RunGeneratedScript");
            /** get QTP instance ***/
            ERROR_CODE eCde = mobjCompiler.InsertRunnableTestScript(strRunnableScript);
            if (eCde != ERROR_CODE._NO_ERROR) return eCde;
#if _tigerDebug
            MessageBox.Show("Wait for setting Debug points action of QTP");
#endif
            eCde = mobjCompiler.RunTest();
            Logger.logEnd("RunGeneratedScript");
            return eCde;
        }
#endif

        private ERROR_CODE GenerateAllRequiredKeywordsDefs(List<ConfigObjectBase> lstSteps, ref StringBuilder strRunnableScript, ref int iErrorStep, ref TestStep objErrStep)
        {
            Logger.logBegin("GenerateAllRequiredKeywordsDefs");
            if (strRunnableScript == null) strRunnableScript = new StringBuilder();
            iErrorStep = 0;
            foreach(ConfigObjectBase objStepNav in lstSteps)
            {
                iErrorStep++;
                if (!(objStepNav is TestStep)) continue;
                strRunnableScript.Append("\r\n");
                strRunnableScript.Append(((TestStep)objStepNav).GetKeyWordsDef());
            }            
            Logger.logEnd("GenerateAllRequiredKeywordsDefs");
            return ERROR_CODE._NO_ERROR;
        }
        
        public void TestConfigFile_Applications()
        {
            ConfigTestApplicationCollection lstApps = AppConfigReader.GetRegApplications();
        }

        public void StopService()
        {
            /** remove all Events handlers **/
            this.mobjFrameworkService.AddGetCurrentTestCaseByTSAndTCEventHandler(mobjXlsBatch.GetCurrentTestCaseByTestSuiteNameAndTestCase, false);
            this.mobjFrameworkService.AddOnNavigateHandler(mobjXlsBatch.OnNavigateHandlerImpl, false);
            this.mobjFrameworkService.AddOnBeginNavigateTestSuiteWithRelyIdAndLoopIdHandler(mobjXlsBatch.OnNavigateWithRelyIdAndLoopIdHandlerImpl, false);
            this.mobjFrameworkService.AddOnGetNextTestSuiteEvent(mobjXlsBatch.OnGetNextTestSuiteEventImpl, false);
            this.mobjFrameworkService.AddOnLoadcurrentTestSuiteEvent(mobjXlsBatch.OnLoadCurrentTestSuiteEventImpl, false);
            this.mobjFrameworkService.AddOnTestSuiteIsDoneEventHandler(mobjXlsBatch.OnTestSuiteIsDoneEventImpl, false);
            this.mobjFrameworkService.AddOnCompileListEventHandler(mobjCompiler.preComplierTestSteps, false);
            string strErrorInfo="" ;
            this.mobjFrameworkService.StopService(ref strErrorInfo);
        }

        public void ChangeBaseLineValue(bool isBaseLineMode)
        {
            if (this.mobjFrameworkService == null)
                return;
            string strBaseLineMode = isBaseLineMode?SystemConstant.CNST_APPCONFIG_APPSETTING_BASELINEMODE_BUILD:SystemConstant.CNST_APPCONFIG_APPSETTING_BASELINEMODE_COMPARE ;
            this.mobjFrameworkService.ChangeBaseLineMode(strBaseLineMode);            
        }

        public void ChangeDefaultApplication(string strCurrentApplicationShortName)
        {
            if (this.mobjFrameworkService == null)
                return;
            string strDefaultApplication = string.Format("ShortName:{0}", strCurrentApplicationShortName);
            this.mobjFrameworkService.ChangeDefaultApplication(strDefaultApplication);
        }

        
    }
}
