﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Oracle.DataAccess.Client;
using System.Data;
using System.Data.Common;

namespace MarsExcelDataProvider
{
    public class OracleUtil
    {
        public static string ConnString;

        public static void oracleTest()
        {
            using (OracleConnection sqlConnection = new OracleConnection(ConnString))
            {
                OracleCommand command = new OracleCommand("select * from TEST_CASE_VIEW ", sqlConnection);
                OracleDataAdapter adapter = new OracleDataAdapter(command);
                OracleCommandBuilder builder = new OracleCommandBuilder(adapter);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                DataTable dt = ds.Tables[0];
                Console.WriteLine("\ndbSource ready for access");
            }
        }

        public static DataSet GenTCDataSet(string testProjectRequested, string testSuiteRequested, List<string> tcList, bool needObjectID)
        {
            DataSet ds = new DataSet();

            string objectIdSnippet = "";

            if (needObjectID)
                objectIdSnippet = " object_id, ";

            foreach (string tc in tcList)
            {
                string sqlQuery = " select key_word_name as keyword,  " +
                                  "        object_happy_name as object,  " +
                                  objectIdSnippet +
                                  "        column_row_setting as row_column " +
                                  " from TEST_CASE_VIEW  " +
                                  " where project_name = '" + testProjectRequested + "'" +
                                  " and test_suite_name = '" + testSuiteRequested + "'" +
                                  " and test_case_name = '" + tc + "'";

                DataTable dt = GetDataTable(sqlQuery);
                Console.WriteLine("tc = " + tc);
                dt.TableName = tc;

                // modify column names
                dt.Columns["KEYWORD"].ColumnName = "keyword";
                dt.Columns["OBJECT"].ColumnName = "object";
                dt.Columns["ROW_COLUMN"].ColumnName = "row_column";

                // add columns
                dt.Columns.Add("value");
                dt.Columns.Add("Comment");

                ds.Tables.Add(dt);
            }

            return ds;
        }

        public static  DataTable GetDataTable(string sqlQuery)
        {
            DataTable dt = null;
            using (OracleConnection sqlConnection = new OracleConnection(ConnString))
            {
                Console.WriteLine(sqlQuery);

                OracleCommand command = new OracleCommand(sqlQuery, sqlConnection);
                OracleDataAdapter adapter = new OracleDataAdapter(command);
                OracleCommandBuilder builder = new OracleCommandBuilder(adapter);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dt = ds.Tables[0];
                ds.Tables.Remove(dt);
            }
            return dt;
        }

        public static  List<string> GetTCList(string projectRequested, string testSuiteRequested)
        {
            List<string> tcList;

            using (OracleConnection sqlConnection = new OracleConnection(ConnString))
            {
                string selectString = " select distinct test_case_name " +
                                      " from TEST_CASE_VIEW " +
                                      " where project_name = '" + projectRequested + "'" +
                                      " and test_suite_name = '" + testSuiteRequested + "'";

                Console.WriteLine(selectString);

                OracleCommand command = new OracleCommand(selectString, sqlConnection);
                OracleDataAdapter adapter = new OracleDataAdapter(command);
                OracleCommandBuilder builder = new OracleCommandBuilder(adapter);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                DataTable dt = ds.Tables[0];
                tcList = dt.AsEnumerable().Select(x => x[0].ToString()).ToList();


                foreach (string e in tcList)
                    Console.WriteLine(e);
            }

            return tcList;
        }

        private static DataSet RunQuery(DbConnection objCnn, DbCommand objCmd, DbDataAdapter objDtaAdpt, DbCommandBuilder objCmdB  )
        {
            try
            {

                return null;
            }
            catch (Exception)
            {
                return null;
                
            }
        }
          
        public static int GetMaxLoopId(string testProjectRequested, string testSuiteRequested)
        {
            int loopId = 0;

            string sqlQuery = " select max(loop_id) as max_loop_id " +
                                  " from TEST_CASE_VIEW   " +
                                  " where project_name = '" + testProjectRequested + "'" +
                                  " and test_suite_name = '" + testSuiteRequested + "'" ;

            DataTable dt = OracleUtil.GetDataTable(sqlQuery);
            
            string ss = dt.Rows[0].ItemArray[0].ToString();
            Int32.TryParse(ss, out loopId);
            return loopId;
        }

        public static DataTable GetDataSheetTable(string testProjectRequested, string testSuiteRequested)
        {
            int maxLoopId = OracleUtil.GetMaxLoopId(testProjectRequested, testSuiteRequested);
            string loopIdSet = GetLoopIdSet(maxLoopId);

            string sqlQuery =
                        " select * from  " +
                        " ( " +
                        "     select object_happy_name as object, data_value as data, loop_id  " +
                        "     from TEST_CASE_VIEW   " +
                        "     where project_name = '" + testProjectRequested + "'" +
                        "     and test_suite_name = '" + testSuiteRequested + "'" +

                        " ) " +
                        " pivot  " +
                        " ( " +
                        "     max(data) " +
                        "     for loop_id in (" + loopIdSet + ")" +
                        " ) ";

            Console.WriteLine(sqlQuery);

            DataTable dt = OracleUtil.GetDataTable(sqlQuery);

            dt.TableName = "Sheet1";

            return dt;
        }

        public static DataTable GetObjectDataTable()
        {
            string sqlQuery = " select * from test_object_view  "; 
            DataTable dt = OracleUtil.GetDataTable(sqlQuery);

            dt.TableName = "Object";
            return dt;
        }

        public static string GetLoopIdSet(int maxLoopId)
        {
            string loopIdSet = "";

            for (int i = 1; i < maxLoopId; i++)
            {
                loopIdSet += i + " as Data" + i + ",";
            }
            loopIdSet += maxLoopId + " as Data" + maxLoopId;

            return loopIdSet;

        }

#if _Datafrom_Database
        /// <summary>
        /// Notice, all methods listing here needs Exception clause outside to catch 
        /// Exception information
        /// </summary>
        private DbConnection CurrentConnection = null;
        private DbConnection GetDbConnection()
        {
            if (CurrentConnection==null)
            {
                CurrentConnection = new OracleConnection(ConnString);
            }
            CurrentConnection.Open();
            return CurrentConnection;
        }
        internal DataSet GenObjects(string strAppShortName = null)
        {
            string strSql = "Select * from V_OBJECT_APPS ";
            string strOrder = "order by OBJECT_TYPE,OBJECT_HAPPY_NAME";
            if (this.CurrentConnection == null)
                GetDbConnection();
            if (strAppShortName == null)
            {
                strSql = string.Format("{0}\r\n{1}", strSql, strOrder);
                return GetDataSetViaSqlParas(this.CurrentConnection, strSql, null, null);
            }
            else
            {
                strSql = string.Format("{0} where APP_SHORT_NAME=:shortName \r\n{1}", strSql, strOrder);
                return GetDataSetViaSqlParas(this.CurrentConnection, strSql, new string[] { "shortName" }, new object[] { strAppShortName });
            }

            
            //using (DbCommand dbCmmd = new OracleCommand(strSql, (OracleConnection)CurrentConnection))
            //{
                
            //    if (isParaMode)
            //    {
            //        dbCmmd.Parameters.Add(new OracleParameter("shortName", strAppShortName));
            //    }
            //    OracleDataAdapter adapter = new OracleDataAdapter((OracleCommand)dbCmmd);
            //    OracleCommandBuilder builder = new OracleCommandBuilder(adapter);
            //    DataSet ds = new DataSet();
            //    adapter.Fill(ds);
            //    return ds;
            //}
            
        }
        internal DataSet GetDataSetViaSqlParas(DbConnection dbCnn, string strSql, string[] arrParas, object[] arrValues) 
        {
            int iLenP = arrParas==null?0:arrParas.Length, iLenV = arrValues == null ? 0 : arrValues.Length;
            if (iLenP!=iLenV)
            {
                throw new System.ArgumentException(string.Format("GetDataSetViaSqlParas, parameters  are wrong.\r\n[arrParas:{0}]-[arrValues:{1}]\r\nSql:{2}", arrParas, arrValues, strSql));
            }
            using (DbCommand dbCmmd = new OracleCommand(strSql, (OracleConnection)dbCnn))
            {
                for (int i=0;i<iLenP;i++)
                {
                    dbCmmd.Parameters.Add(new OracleParameter(arrParas[i], arrValues[i]));
                }
                OracleDataAdapter adapter = new OracleDataAdapter((OracleCommand)dbCmmd);
                OracleCommandBuilder builder = new OracleCommandBuilder(adapter);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                return ds;
            }
        }
#endif
    }
}
