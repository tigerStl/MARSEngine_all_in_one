﻿using com.Mars.Constants;
using com.Mars.TestFrame.Application;
using com.Mars.TestFrame.TestObjects;
using MarsTestFrame.CommuniteServer;
using MarsTestFrame.SourceCode.com.Mars.KeyWords.KeyWordObject;
using MarsTestFrame.systemUtil;
using Route2NSEx.src.Marquis.systemUtil;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.RegularExpressions;

namespace MarsTestFrame.com.Mars.TestConfigObjects
{
    [Serializable]
    public class ConfigObjectBase
    {
        public override string ToString()
        {
            return "";
        }


    }
    public class BatchConfigObject : ConfigObjectBase
    {
        #region properties
        protected string mstrAction;
        protected string mstrTCFilePath;
        protected string mstrTCSheetName;
        protected string mstrID;
        protected string mstrPrefixId;
        protected string mstrRunResult;
        #endregion properties

        public string Action /*** run/Skip ***/
        {
            get { return this.mstrAction; }
            set { this.mstrAction = value; }
        }
        public string TCFilePath
        {
            get { return this.mstrTCFilePath; }
            set { this.mstrTCFilePath = value; }
        }
        public string TCSheetName
        {
            get { return this.mstrTCSheetName; }
            set { this.mstrTCSheetName = value; }
        }
        public string TestSuiteID
        {
            get { return this.mstrID; }
            set { this.mstrID = value; }
        }

        public string PreParentId { get { return this.mstrPrefixId; }
            set { this.mstrPrefixId = value; }
        }

        public string RunResult
        {
            get { return this.mstrRunResult; }
            set { this.mstrRunResult = value; } 
        }

        public override string ToString()
        {
            return string.Format("Action=[{0}], TCFilePath=[{1}], TCSheet=[{2}]", this.Action, this.TCFilePath, this.TCSheetName);
        }
    }
    #region subActions' class


    [Serializable]
    public class SubTestStepInfo : ConfigObjectBase
    {
        private static MLogger Logger = MLogger.GetLogger(typeof(SubTestStepInfo));
        protected List<ConfigObjectBase> SubActions = new List<ConfigObjectBase>();

        public string Keyword{get;set;}
        
        internal virtual List<ConfigObjectBase> GetSubActions()
        {
            return SubActions;
        }

        internal virtual ERROR_CODE BuildSubActionList(int iLoop)
        {
            return ERROR_CODE._NO_ERROR;
        }

        public static SubTestStepInfo CreateSubTestStepInfoFactory(string strKeyword, string strValue, string strRCInfo, ref ERROR_CODE eCde)
        {
            switch (strKeyword.ToUpper())
            {
                case SystemConstant.CNST_SUBACTION_KEYWORD_IF:
                    IFTestStepInfo objIF = new IFTestStepInfo();
                    eCde = IFTestStepInfo.ParseSubObject(ref objIF, strKeyword, strValue);
                    if (eCde != ERROR_CODE._NO_ERROR) return null;
                    else return objIF;
                case SystemConstant.CNST_SUBACTION_KEYWORD_CALL:
                    return null;
                case SystemConstant.CNST_SUBACTION_KEYWORD_BUSINESSALLOCATION:
                case SystemConstant.CNST_SUBACTION_KEYWORD_DEALERALLOCATION:
                    return null;
                default:
                    eCde = ERROR_CODE._COMPILER_SUBACTION_KEYWORD_IS_NOT_A_SUBACTION_PARA_1;
                    Logger.Error("CreateSubTestStepInfoFactory", string.Format(ERROR_INFO.GET_ERROR_STR(eCde), strKeyword));
                    return null;   
            }
        }

        public virtual ERROR_CODE CloneObject2SeviceObj(SubTestInfo4Services objTarget)
        {
            ERROR_CODE eCde =ERROR_CODE._NO_ERROR;                  
            return eCde;
        }
    }    

    [DataContract]
    public class IFSubItemInfo:ConfigObjectBase
    {
        [DataMember]
        public string PropertyName;
        [DataMember]
        public string OperationMark;
        [DataMember]
        public string Value2Compare;
        [DataMember]
        public string AssociatedAction;
        [DataMember]
        public string ReturnValue;
        [DataMember]
        public string SubKeyword;
        [DataMember]
        public string SubObjectAndOthers;

        public IFSubItemInfo4Services Clone2ServiceObject()
        {
            IFSubItemInfo4Services objIFSubItem = new IFSubItemInfo4Services();
            objIFSubItem.AssociatedAction = this.AssociatedAction;
            objIFSubItem.OperationMark = this.OperationMark;
            objIFSubItem.PropertyName = this.PropertyName;
            objIFSubItem.ReturnValue = this.ReturnValue;
            objIFSubItem.SubKeyword = this.SubKeyword;
            objIFSubItem.SubObjectAndOthers = this.SubObjectAndOthers;
            objIFSubItem.Value2Compare = this.Value2Compare;
            return objIFSubItem;
        }
    }

    [Serializable]
    public class IFTestStepInfo : SubTestStepInfo
    {
        private static MLogger Logger = MLogger.GetLogger(typeof(IFTestStepInfo));

        internal List<IFSubItemInfo> mlstSubIfItmInfo;

        internal override List<ConfigObjectBase> GetSubActions()
        {
            return base.GetSubActions();
        }

        internal override ERROR_CODE BuildSubActionList(int iLoop)
        {
            //protected List<ConfigObjectBase> SubActions
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR ;
            SubActions.Clear();
            int iRunID = 0;
            foreach(IFSubItemInfo objIFItm in this.mlstSubIfItmInfo)
            {                
                TestStep objTestStp = new TestStep();
                objTestStp.Keyword = objIFItm.SubKeyword;
                objTestStp.ObjectName = objIFItm.SubObjectAndOthers;
                objTestStp.Loop = iLoop;
                objTestStp.Row_Column = "";
                objTestStp.Value = "";
                objTestStp.RunID = iRunID++;
                SubActions.Add(objTestStp);
            }
            return eCde;
        }

        internal static ERROR_CODE ParseSubObject(ref IFTestStepInfo objIFSubAction, string strKeyword, string strValue)
        {
            objIFSubAction.Keyword = strKeyword;
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;

            string[] arrValueItems = strValue.Split(new string[]{"\n"}, StringSplitOptions.RemoveEmptyEntries);
            List<IFSubItemInfo> lstItemInfo = new List<IFSubItemInfo>();
            foreach (string strItm in arrValueItems)
            {
                string strItm2Parse = strItm.Replace("\r", "");
                Regex objReg = new Regex(SystemConstant.CNST_IF_REGQULOR_PARSE);
                string[] arrInfo = objReg.Split(strItm2Parse);
                if (arrInfo.Length != 7)
                {
                    eCde = ERROR_CODE._KEYWORDS_IF_FORMATTER_SETTING_ERROR_PARA_1;
                    Logger.Error("ParseSubObject", string.Format(ERROR_INFO.GET_ERROR_STR(eCde), strValue));
                    return eCde;
                }
                IFSubItemInfo objIfSubItem = new IFSubItemInfo();
                //@"(>|<|=|>=|<=){1}(\d+)\?return\=(true|false):(\S+)\[(\S+)\]"
                objIfSubItem.PropertyName = arrInfo[0];
                objIfSubItem.OperationMark = arrInfo[1];
                objIfSubItem.Value2Compare = arrInfo[2];
                objIfSubItem.ReturnValue = arrInfo[3];
                objIfSubItem.SubKeyword = arrInfo[4];
                objIfSubItem.SubObjectAndOthers = arrInfo[5];

                lstItemInfo.Add(objIfSubItem);
            }

            objIFSubAction.mlstSubIfItmInfo = lstItemInfo;
            return ERROR_CODE._NO_ERROR;
        }

        public override ERROR_CODE CloneObject2SeviceObj(SubTestInfo4Services objTarget)
        {
            /** **/
            ERROR_CODE eCde =ERROR_CODE._NO_ERROR;
            if (objTarget == null) return eCde;

            if (!(objTarget is IFSubTestInfo4Services))
            {
                eCde = ERROR_CODE._SERVICE_ERROR_IF_SUBOBJECT_REQUIRED_PARA_1;
                Logger.Error("CloneObject2ServiceObj", string.Format(ERROR_INFO.GET_ERROR_STR(eCde), objTarget.GetType().ToString()));
                return eCde;
            }
            if (this.SubActions == null) return eCde;

            objTarget.keyword = SystemConstant.CNST_SUBACTION_KEYWORD_IF;

            IFSubTestInfo4Services objIFtarget = (IFSubTestInfo4Services)objTarget;
            objIFtarget.SubIFItems = new List<IFSubItemInfo4Services>() ;                        
            for (int i = 0; i < this.mlstSubIfItmInfo.Count; i++)
            {
                IFSubItemInfo objIFSubItm = ((IFSubItemInfo)(this.mlstSubIfItmInfo[i]));                
                IFSubItemInfo4Services obj4Service = objIFSubItm.Clone2ServiceObject() ;
                objIFtarget.SubIFItems.Add(obj4Service) ;
            }

            /** clone sub Actions **/
            objTarget.SubActions = new List<TestStep4Services>();            
            for (int i = 0; i < this.SubActions.Count;i++ )
            {
                if (!(SubActions[i] is TestStep))
                {
                    continue;
                }
                TestStep objStep = (TestStep)SubActions[i];
                TestStep4Services objStep4Service = new TestStep4Services() ;
                objStep.CloneToService(objStep4Service);
                objTarget.SubActions.Add(objStep4Service);
            }
            return eCde;
        }
    }

    #endregion //sub Actions' class

    [Serializable]
    public class TestStep : ConfigObjectBase
    {
        private MLogger Logger = MLogger.GetLogger(typeof(TestStep));
        #region member Var
        private string mstrKeyWord;
        private string mstrObject;
        private string mstrRCParameter;
        private string mstrValue;
        private string mstrQuickAccess;
        private string mstrComment;
        private int miLoop = -1;
        private int miRunID = -1;
        private List<string> mlstData = null;
        protected List<TargetApplicationInfo> ApplicationListRunOn = null;
        #endregion

        #region property
        public int RunID{get{return this.miRunID ;}set{this.miRunID=value ;}} 
        public string Keyword { get { return this.mstrKeyWord; } set { this.mstrKeyWord = value; } }
        public string ObjectName { get { return this.mstrObject; } set { this.mstrObject = value; } }
        public string Row_Column { get { return this.mstrRCParameter; } set { this.mstrRCParameter = value; } }
        public string Value { get { return this.mstrValue; } set { this.mstrValue = value; } }
        public string QuickAccess { get { return this.mstrQuickAccess; } set { this.mstrQuickAccess = value; } }
        public string Comment { get { return this.mstrComment; } set { this.mstrComment = value; } }
        public int Loop { get { return this.miLoop; } set { this.miLoop = value; } }
        public List<TestPegwindowObject> Pegwindows = null;
        public KeyWordObjectInfo KeyWordFuntion = null;
        public string ObjectFullpath = null;

        public SubTestStepInfo SubActionObject = null ;
        #endregion

        #region subActions segment
        public bool isSubActionStep()
        {
            
            return SubActionObject == null;
        }

        public ERROR_CODE ParseSubAction(int iCurrentLoop)
        {
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            SubTestStepInfo objSubAction = SubTestStepInfo.CreateSubTestStepInfoFactory(this.Keyword, this.Value, this.Row_Column, ref eCde);
            if (eCde != ERROR_CODE._NO_ERROR) return eCde;
            eCde = objSubAction.BuildSubActionList(iCurrentLoop);
            if (eCde == ERROR_CODE._NO_ERROR)
                SubActionObject = objSubAction;
            else
                SubActionObject = null;
            return eCde;
        }
        #endregion //subActions Segment

        /** copy value to another Test Step object **/
        internal void CloneTo(TestStep objTarget)
        {
            if (objTarget == null) return;
            objTarget.Keyword = this.Keyword;
            objTarget.ObjectName = this.ObjectName;
            objTarget.Row_Column = this.Row_Column;
            objTarget.Value = this.Value;
            objTarget.QuickAccess = this.QuickAccess;
            objTarget.Comment = this.Comment;
            objTarget.Loop = this.Loop;
            objTarget.RunID = this.RunID;
            if (this.Pegwindows!=null)
            {
                objTarget.Pegwindows = new List<TestPegwindowObject>();
                for(int i=0 ;i<this.Pegwindows.Count ;i++)
                {
                    objTarget.Pegwindows.Add(Pegwindows[i]);
                }
            }
            objTarget.KeyWordFuntion = this.KeyWordFuntion;
            objTarget.ObjectFullpath = this.ObjectFullpath;
        }

        internal void CloneToService(TestStep4Services objServiceObj)
        {
            if (objServiceObj == null) return;
            objServiceObj.Comment = this.Comment;
            objServiceObj.Keyword = this.Keyword;
            objServiceObj.Loop = this.Loop;
            objServiceObj.ObjectName = this.ObjectName;
            objServiceObj.QuickAccess = string.IsNullOrEmpty(this.QuickAccess)?this.ObjectFullpath:this.QuickAccess;
            objServiceObj.Row_Column = this.Row_Column;
            objServiceObj.Value = this.Value;
            objServiceObj.RunID = this.RunID;
            Logger.Info("--ServerQuick--", string.Format("Client quick:[{0}], server:FullPath:[{1}], Server quick:[{2}]", objServiceObj.QuickAccess, this.ObjectFullpath, this.QuickAccess));
            if (this.SubActionObject is IFTestStepInfo)
            {
                IFSubTestInfo4Services objIFSubs = new IFSubTestInfo4Services();
                this.SubActionObject.CloneObject2SeviceObj(objIFSubs);
                objServiceObj.SubTestInfo = objIFSubs;
            }
            else
            {
                //objServiceObj.
            }
        }

        public ERROR_CODE BuildObjectFullPath(ref string strErrorInfo)
        {
            Logger.logBegin("BuildObjectFullPath");
            try
            {
                ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
                if ((mstrQuickAccess != null) && (mstrQuickAccess.Trim().Length != 0))
                {
                    ObjectFullpath = mstrQuickAccess;
                }
                else
                {
                    string[] arrPegsName = GetPegwindowNames();
                    if ((arrPegsName == null) || (arrPegsName.Length == 0))
                    {
                        eCde = ERROR_CODE._COMPILER_NO_PEGWINDOW_FOR_TESTSTEP_FIND;
                        Logger.Error("BuildObjectFullPath", strErrorInfo=ERROR_INFO.GET_ERROR_STR(eCde));
                        return eCde;
                    }
                    /** get Object Identify information **/
                    ConfigObjectBase objTestObjInfo = TestObjectsManagement.GetObjectInfomationByPegwindow(ApplicationListRunOn[0].ApplicationShortName, Pegwindows[0].ObjectName, this.ObjectName);
                    if (objTestObjInfo is TestObject)
                    {
                        /** check whether Runtime windows information is applied **/
                        TestPegwindowObject objRuntimePeg = GetRuntimePegInfo();
                        if (((TestObject)objTestObjInfo).IsPegwindowObject())
                        {
                            if (objRuntimePeg == null)
                                ObjectFullpath = string.Format("{0}", Pegwindows[0].FullPathAccess);
                            else
                                ObjectFullpath = string.Format("{0}", objRuntimePeg.FullPathAccess);
                        }
                        else
                        {
                            if (objRuntimePeg == null)
                                ObjectFullpath = string.Format("{0}.{1}", Pegwindows[0].FullPathAccess, ((TestObject)objTestObjInfo).FullPathAccess);
                            else
                                ObjectFullpath = string.Format("{0}.{1}", objRuntimePeg.FullPathAccess, ((TestObject)objTestObjInfo).FullPathAccess);
                        }
                        mstrQuickAccess = string.IsNullOrEmpty(mstrQuickAccess) ? ObjectFullpath : mstrQuickAccess;
                        Logger.Info("---BuildObjectFullPath.QuickAccess---", string.Format("FullPath:[{0}], Quick:[{1}]", ObjectFullpath, mstrQuickAccess));
                    }
                    else
                    {
                        eCde = ERROR_CODE._COMPILER_NO_OBJECT_INDENTIFY_INFO;
                        string strErr = string.Format(ERROR_INFO.GET_ERROR_STR(eCde), this.mstrObject, arrPegsName[0]);
                        Logger.Error("BuildObjectFullPath", strErrorInfo=strErr);
                        return eCde;
                    }
                }
                return ERROR_CODE._NO_ERROR;
            }
            finally
            {
                Logger.logEnd("BuildObjectFullPath");
            }

        }

        private TestPegwindowObject GetRuntimePegInfo()
        {
            Logger.logBegin("IsUseRuntime");
            try
            {
                if (Pegwindows == null) return null;
                foreach(TestPegwindowObject objPeg in Pegwindows)
                {
                    if (objPeg == null) continue;
                    TestPegwindowObject objPegRun = objPeg.GetRunTimePegWindow();
                    if (objPegRun == null) continue;
                    return objPegRun;
                }
                return null;
            }
            finally
            {
                Logger.logEnd("IsUseRunTime");
            }
        }

        public ERROR_CODE ValidateStepSetting()
        {
            Logger.logBegin("ValidateStepSetting");
            try
            {
                if (KeyWordFuntion == null)
                {
                    Logger.Info("ValidateStepSetting", MarsTestFrame.Properties.Resources.HINT_KEYWORD_VALIDATE_NO_VALIDATECLASS_RETURN_TRUE);
                    return ERROR_CODE._NO_ERROR;
                }
                if (KeyWordFuntion.ParseInstance == null)
                {
                    Logger.Info("ValidateStepSetting", MarsTestFrame.Properties.Resources.HINT_KEYWORD_VALIDATE_NO_VALIDATECLASS_RETURN_TRUE);
                    return ERROR_CODE._NO_ERROR;
                }
                E_KeywordParameterID eKeyWordPara = KeyWordFuntion.ParseInstance.IsParameterRequired();
                bool isSettingCorrect = true;
                string[] arrAppshortNames = new string[] { };
                ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
                if ((eKeyWordPara & E_KeywordParameterID.e_Keyword_Parameter_object) == E_KeywordParameterID.e_Keyword_Parameter_object)
                {
                    /** GET pegwindow name **/
                    string[] arrPegsName = GetPegwindowNames();
                    if ((arrPegsName == null) || (arrPegsName.Length == 0))
                    {
                        eCde = ERROR_CODE._COMPILER_NO_PEGWINDOW_FOR_TESTSTEP_FIND;
                        Logger.Error("ValidateStepSetting", ERROR_INFO.GET_ERROR_STR(eCde));
                        return eCde;
                    }
                    /** check object is required by keyword **/
                    isSettingCorrect = isSettingCorrect && ((eCde = CheckApplicationsValidate(ref arrAppshortNames)) == ERROR_CODE._NO_ERROR);
                    if (isSettingCorrect)
                    {
                        isSettingCorrect = KeyWordFuntion.ParseInstance.IsRightFormatForObject(arrAppshortNames[0], arrPegsName[0], this.ObjectName, ref eCde);
                        if (!isSettingCorrect)
                        {
                            return eCde;
                        }
                        isSettingCorrect = true;
                    }
                    else
                    {
                        return eCde;
                    }
                }
                if (((eKeyWordPara & E_KeywordParameterID.e_Keyword_Parameter_RC) == E_KeywordParameterID.e_Keyword_Parameter_RC) && (isSettingCorrect))
                {
                    /** RC should not be empty **/
                    if (this.Row_Column == null)
                    {
                        eCde = ERROR_CODE._COMPILER_NO_RC;
                        string strError = string.Format(ERROR_INFO.GET_ERROR_STR(eCde), string.Format("keyword:[{0}], object:[{1}]", this.Keyword, this.ObjectName));
                        Logger.Error("ValidateStepSetting", strError);
                        return eCde;
                    }
                }

                return ERROR_CODE._NO_ERROR;
            }
            finally
            {
                Logger.logEnd("ValidateStepSetting");
            }
        }

        protected string[] GetPegwindowNames()
        {
            Logger.logBegin("GetPegwindowNames");
            try
            {
                List<string> lstPegsName = new List<string>();
                foreach (TestPegwindowObject objPeg in this.Pegwindows)
                {
                    lstPegsName.Add(objPeg.ObjectName);
                }
                return lstPegsName.ToArray();
            }
            finally
            {
                Logger.logEnd("GetPegwindowNames");
            }
        }

        private ERROR_CODE CheckApplicationsValidate(ref string[] arrApplicationShorts)
        {
            Logger.logBegin("CheckApplicationsValidate");
            try
            {
                string[] arrApplications = this.GetApplicationShortName();
                if (arrApplications == null)
                {
                    return ERROR_CODE._NO_ERROR;
                }
                if (arrApplications.Length != 1)
                {
                    Logger.Error("CheckApplicationsValidate", ERROR_INFO.GET_ERROR_STR(ERROR_CODE._COMPILER_APPLICATON_LENTH_NOT_1));
                    return ERROR_CODE._COMPILER_APPLICATON_LENTH_NOT_1;
                }

                return ERROR_CODE._NO_ERROR;
            }
            finally
            {
                Logger.logEnd("CheckApplicationsValidate");
            }

        }



        public void AddApplicationInfo(string strShortName, TargetApplicationInfo appObj)
        {
            Logger.logBegin("AddApplicationInfo");
            if (ApplicationListRunOn == null) ApplicationListRunOn = new List<TargetApplicationInfo>();
            if (strShortName == null) return;
            foreach (TargetApplicationInfo objApp in ApplicationListRunOn)
            {
                if (objApp == null) continue;
                if (string.Compare(strShortName, objApp.ApplicationShortName, true) == 0) return;
            }
            ApplicationListRunOn.Add(appObj);
            Logger.logEnd("AddApplicationInfo");
        }

        public string[] GetApplicationShortName()
        {
            if (ApplicationListRunOn == null) return null;
            List<string> lstResult = new List<string>();
            foreach (TargetApplicationInfo objApplication in ApplicationListRunOn)
            {
                lstResult.Add(objApplication.ApplicationShortName);
            }
            return lstResult.ToArray();
        }

        public void AddPegWindowInfo(TestPegwindowObject objPeg)
        {
            Logger.logBegin("AddPegWindowInfo");
            if (Pegwindows == null) Pegwindows = new List<TestPegwindowObject>();
            foreach (TestPegwindowObject objPegIn in Pegwindows)
            {
                if (objPegIn == null) continue;
                if (string.Compare(objPeg.ObjectName, objPegIn.ObjectName, true) == 0) return;
            }
            Pegwindows.Add(objPeg);

            Logger.logEnd("AddPegWindowInfo");
        }

        public void AddPegWindowInfo(List<TestPegwindowObject> lstPeg)
        {
            Pegwindows = lstPeg;
        }

        public TestPegwindowObject[] GetPegWindows()
        {
            return this.Pegwindows==null?null:this.Pegwindows.ToArray<TestPegwindowObject>();
        }


        public void InitializeDataList()
        {
            Logger.logBegin("InitializeDataList");
            if (mlstData == null)
                mlstData = new List<string>();
            mlstData.Clear();
            Logger.logEnd("InitializeDataList");
        }

        public void AddOneItemToDataList(string strItem)
        {
            Logger.logBegin("AddOneItemToDataList");
            if (mlstData == null)
                InitializeDataList();
            mlstData.Add(strItem);
            Logger.logEnd("AddOneItemToDataList");
        }

        public override string ToString()
        {
            return string.Format("\tKeyWord:[{0}],\r\n\tObject:[{1}],\r\n\tRC:[{2}],\r\n\tValue:[{3}],\r\n\tComment:[{4}]", this.Keyword, this.ObjectName, this.Row_Column, this.Value, this.Comment);
        }

        internal string GetKeyWordsDef()
        {
            Logger.logBegin("GetKeyWordsDef");
            if (this.KeyWordFuntion == null) return "";
            string strScript = KeyWordFuntion.GetKeywordDefScript();
            Logger.logEnd("GetKeyWordsDef");
            return strScript;
        }

        internal ERROR_CODE BuildPegWindowObjectFullPath(List<TestPegwindowObject> lstPegs)
        {
            Logger.logBegin("BuildPegWindowObjectFullPath");

            if (!string.IsNullOrEmpty(mstrQuickAccess)) return ERROR_CODE._NO_ERROR;
            if (lstPegs == null) return ERROR_CODE._NO_ERROR;
            if (lstPegs.Count == 0) return ERROR_CODE._NO_ERROR;
            if (string.IsNullOrEmpty(lstPegs[0].QuickAccessString))
            {
                Logger.Error("BuildPegWindowObjectFullPath", string.Format(ERROR_INFO.GET_ERROR_STR(ERROR_CODE._COMPILER_NO_PEGWINDOW_IDENTIFIERINFO), this.ObjectName));
                return ERROR_CODE._COMPILER_NO_PEGWINDOW_IDENTIFIERINFO;
            }

            /** more than one pegwindows are available. but until 2015-Mar. no support for that **/
            string[] arrPegSubItems = lstPegs[0].QuickAccessString.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries);
            string strMultId = string.Format("\"{0}\"", string.Join("\",\"", arrPegSubItems));

            this.mstrQuickAccess = string.Format("Window({0})", strMultId);
            lstPegs[0].FullPathAccess = this.mstrQuickAccess;

            Logger.logEnd("BuildPegWindowObjectFullPath");
            return ERROR_CODE._NO_ERROR;
        }

        internal List<ConfigObjectBase> GetSubActions()
        {
            if (SubActionObject == null) return null;
            return SubActionObject.GetSubActions();
        }
    }

    

    public class TestObject : ConfigObjectBase
    {
        private static MLogger Logger = MLogger.GetLogger(typeof(TestObject));

        #region members
        protected string mstrFullPathAccess = "";
        #endregion

        #region properties
        public string ObjectName;
        public string ObjectType;
        public string QuickAccessString;
        public string Description;

        public string FullPathAccess { get { return mstrFullPathAccess; } set { this.mstrFullPathAccess = value; } }
        #endregion

        public bool IsPegwindowObject()
        {
            return (string.Compare(ObjectType, SystemConstant.CNST_RESERVED_KEYWORD_PEGWINDOW, true) == 0) 
#if _ver1_5
                || (string.Compare(ObjectType, SystemConstant.CNST_RESERVED_KEYWORD_PEG_WPF,true)==0)
                || (string.Compare(ObjectType, SystemConstant.CNST_RESERVED_KEYWORD_PEG_STANDARD,true)==0)
                || (string.Compare(ObjectType, SystemConstant.CNST_RESERVED_KEYWORD_PEG_DIALOG, true) == 0)
                || (string.Compare(ObjectType, SystemConstant.CNST_RESERVED_KEYWORD_PEG_SWFWINDOW, true) == 0)
#endif
                ;
        }

        public static bool IsPegwindowObject(string strObjType)
        {
            return string.Compare(strObjType, SystemConstant.CNST_RESERVED_KEYWORD_PEGWINDOW, true) == 0
#if _ver1_5
                || (string.Compare(strObjType, SystemConstant.CNST_RESERVED_KEYWORD_PEG_WPF, true) == 0)
                || (string.Compare(strObjType, SystemConstant.CNST_RESERVED_KEYWORD_PEG_STANDARD, true) == 0)
                || (string.Compare(strObjType, SystemConstant.CNST_RESERVED_KEYWORD_PEG_DIALOG, true) == 0)
                || (string.Compare(strObjType, SystemConstant.CNST_RESERVED_KEYWORD_PEG_SWFWINDOW, true) == 0)
#endif
                ;
        }

        

        public ERROR_CODE ValidateParameters()
        {
            throw new NotImplementedException();
        }

        public ERROR_CODE BuildPegQuickAcessString()
        {
            if (!string.IsNullOrEmpty(this.mstrFullPathAccess)) return ERROR_CODE._NO_ERROR;
            if (IsPegwindowObject())
            {
                string strQuickAccess = QuickAccessString.Replace("\r", "");
                string[] arrIds = strQuickAccess.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries);
                string strMultId = string.Format("\"{0}\"", string.Join("\",\"", arrIds));
#if _ver1_5
                string strPegWinPrefix = "Window";
                if (string.Compare(ObjectType, SystemConstant.CNST_RESERVED_KEYWORD_PEG_WPF, true) == 0)
                {
                    strPegWinPrefix = "WPFWindow";
                }
                if (string.Compare(ObjectType, SystemConstant.CNST_RESERVED_KEYWORD_PEG_DIALOG, true) == 0)
                {
                    strPegWinPrefix = "Dialog";
                }
                if (string.Compare(ObjectType, SystemConstant.CNST_RESERVED_KEYWORD_PEG_SWFWINDOW, true) == 0)
                {
                    strPegWinPrefix = "SwfWindow";
                }
                this.mstrFullPathAccess = string.Format("{1}({0})", strMultId, strPegWinPrefix);
#else
                this.mstrFullPathAccess = string.Format("Window({0})", strMultId);
#endif


                return ERROR_CODE._NO_ERROR;
            }
            else
            {
                string strQuickAccess = QuickAccessString==null?"":QuickAccessString.Replace("\r", "");
                string[] arrIds = strQuickAccess.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries);
                string strMultId = string.Format("\"{0}\"", string.Join("\",\"", arrIds));
                this.mstrFullPathAccess = string.Format("{1}({0})", strMultId, this.ObjectType);

                return ERROR_CODE._NO_ERROR;
            }
        }

        public virtual TestObject Clone()
        {
            Logger.logBegin("Clone");

            TestObject objNew = new TestObject();
            Logger.Info("Clone", ToString());
            objNew.ObjectType = this.ObjectType;
            objNew.ObjectName = this.ObjectName;
            objNew.QuickAccessString = this.QuickAccessString;
            objNew.FullPathAccess = this.FullPathAccess;
            objNew.Description = this.Description;
            Logger.logEnd("Clone");

            return objNew;
        }

        public override string ToString()
        {
            return string.Format(
                "{0}\r\n\t{1}\r\n\t{2}\r\n\t{3}\r\n\t{4}",
                TigerMarsUtil.GetParameter("Object Name", this.ObjectName),
                TigerMarsUtil.GetParameter("Object Type", this.ObjectType),
                TigerMarsUtil.GetParameter("Quick AccessString", this.QuickAccessString),
                TigerMarsUtil.GetParameter("Description", this.Description),
                TigerMarsUtil.GetParameter("FullPath Access", this.FullPathAccess)
            );
        }
    }

    public class TestRuntimePegwindow
    {
        private static MLogger Logger = MLogger.GetLogger(typeof(TestRuntimePegwindow));
        public string RuntimePegWindowName { get; set; }
        public TestObject RuntimePegwindow { get; set; }
        public static bool isRuntimePegWindow(string strValueToCheck)
        {
            Logger.logBegin("isRuntimePegWindow");
            string strPart = string.Format("^{0}", SystemConstant.CNST_ENHANCE_PEG_RUNTIME_PREFIX);
            bool isMatch = TigerMarsUtil.RegularTest(strPart, strValueToCheck);
            Logger.logEnd("isRuntimePegWindow");
            return isMatch;
        }
        public static string GetRuntimePegInfo(string strValueToCheck)
        {
            Logger.logBegin("GetRuntimePegInfo");
            string strResult = strValueToCheck.Replace(SystemConstant.CNST_ENHANCE_PEG_RUNTIME_PREFIX, "");
            Logger.logEnd("GetRuntimePegInfo");
            return strResult;
        }
    }

    public class TestPegwindowObject : TestObject
    {
        private static MLogger Logger = MLogger.GetLogger(typeof(TestPegwindowObject));
        public List<ConfigObjectBase> ChildrenObjects = null;

        private TestRuntimePegwindow RuntimePegInfo = null;

        public TestObject GetChildrenObjctsByName(string strObjName)
        {
            Logger.logBegin("GetChildrenObjctsByName");
            foreach (ConfigObjectBase objChild in this.ChildrenObjects)
            {
                if (!(objChild is TestObject)) continue;
                if (string.Compare((objChild as TestObject).ObjectName, strObjName, true) == 0)
                {
                    return objChild as TestObject;
                }
            }
            return null;
        }

        public TestRuntimePegwindow GetRunTimePegInfo()
        {
            return RuntimePegInfo;
        }
        public TestPegwindowObject GetRunTimePegWindow()
        {
            return RuntimePegInfo == null ? null : (TestPegwindowObject)(RuntimePegInfo.RuntimePegwindow);
        }

        public void SetRuntimePegInfo(string strRunTimePegName, TestPegwindowObject objPeg)
        {
            if (objPeg == null) return;
            RuntimePegInfo = new TestRuntimePegwindow();
            RuntimePegInfo.RuntimePegWindowName = strRunTimePegName;
            RuntimePegInfo.RuntimePegwindow = objPeg;
        }

        public override TestObject Clone()
        {
            Logger.logBegin("Clone");
            TestPegwindowObject objNew = new TestPegwindowObject();
            objNew.ObjectName = this.ObjectName;
            objNew.ObjectType = this.ObjectType;
            objNew.QuickAccessString = this.QuickAccessString;
            objNew.FullPathAccess = this.FullPathAccess;
            objNew.Description = this.Description;
            if (this.ChildrenObjects != null)
            {
                objNew.ChildrenObjects = new List<ConfigObjectBase>();
                foreach (ConfigObjectBase objItem in this.ChildrenObjects)
                {
                    objNew.ChildrenObjects.Add(objItem);
                }
            }
            Logger.logEnd("Clone");
            return objNew;
        }


    }

    public class TestDataObject : ConfigObjectBase
    {
        private static MLogger Logger = MLogger.GetLogger(typeof(TestDataObject));

        #region Properties
        public string DataObjectName;
        public List<string> TestData = new List<string>();
        #endregion

        public string GetSpecialColumnData(int iColumn, ref ERROR_CODE eCde)
        {
            Logger.logBegin("GetSpecialColumnData");
            if (TestData == null)
            {
                eCde = ERROR_CODE._TCDATA_NO_DATA_FIND;
                Logger.Error("GetSpecialColumnData", string.Format(ERROR_INFO.GET_ERROR_STR(eCde), DataObjectName));
                return null;
            }
            if ((iColumn < 0) || (iColumn >= this.TestData.Count))
            {
                eCde = ERROR_CODE._TCDATA_DATA_COLUMN_EXCEED;
                Logger.Error("GetSpecialColumnData", ERROR_INFO.GET_ERROR_STR(eCde));
                return null;
            }

            string strResult = TestData[iColumn];
            Logger.logEnd(string.Format("GetSpecialColumnData -{0}", TigerMarsUtil.GetParameter("value", strResult)));
            return strResult;
        }

        internal int GetColumnCount()
        {
            Logger.logBegin("GetColumnCount");
            Logger.logEnd("GetColumnCount");
            return TestData == null ? int.MinValue : TestData.Count;
        }
    }

}
