﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;

using System.Reflection;

using MarsTestFrame.SourceCode.systemUtil;

using System.Collections;

using System.Text.RegularExpressions;
using com.Mars.MarsTestingFrame;
using MarsTestFrame.SourceCode.com.Mars.KeyWords;
using MarsTestFrame.SourceCode.com.Mars.QTP;
using System.Data.OleDb;
using System.Data;
using System.IO;
using TestFrameStarter.TestProjects;
using System.Windows.Threading;
using com.Mars.Config;
using com.Mars.TestFrame.Application;
using MarsTestFrame.systemUtil;
namespace TestFrameStarter
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        public MainWindow()
        {
            InitializeComponent();
            
            //this.Icon = TestFrameStarter.Properties.Resources.favicon.;
        }
        MarsTestFrameMain objMarsTestingFrame = new MarsTestFrameMain();

        private void Button_Click(object sender, RoutedEventArgs e)
        {

#region license info
            bool isShowLicenseInfo = false;
            if (((App)Application.Current).gLicenseMgr==null)
            {
                isShowLicenseInfo = true;
            }
            else
            {
                isShowLicenseInfo = !((App)Application.Current).gLicenseMgr.isAvailable() ;
            }
            if (isShowLicenseInfo)
            {
                MessageBox.Show("Mars Automation Testing framework is expired already.\r\nPlease contact Marquis Business Tech solution LLC renewwing.","WARNING") ;
                return ;
            }
#endregion //license Info

            /** kill all QTP instances **/
            string strQptRoot = AppConfigReader.GetQtpRoot();
            /*strQptRoot = strQptRoot == null ? "" : strQptRoot.Replace("\\", "\\\\");
            strQptRoot = strQptRoot == null ? "" : strQptRoot.Replace("(", "\\(");
            strQptRoot = strQptRoot == null ? "" : strQptRoot.Replace(")", "\\)");*/
            TigerMarsUtil.KillProcessBelong2TargetFold(strQptRoot);

            /** switch QTP Testadvantage replacement information **/
            /** for administrative priviledge **/
            /* 
            if (SwitchSwfConfig() != 1)
            {
                return;
            } */
            /** for non-administrative priviledge **/
            if (SwitchAddinsVersion() != 1)
            {
            }

            //
            //objMarsTestingFrame = null;
            if (this.AvailableProjects.SelectedIndex < 0 )
            {
                this.Dispatcher.BeginInvoke(
                    DispatcherPriority.Background,
                    new Action(delegate() 
                        { 
                        MessageBox.Show("Please select one Test Project to Run!", "Hint"); 
                        }
                        )
                    );
                return;
            }

            objMarsTestingFrame.CurrentTestProjectName=this.AvailableProjects.SelectedItem.ToString();
            objMarsTestingFrame.CurrentTestApplicationShortName = this.AvailableApps.SelectedItem.ToString();
            string strCurrentTestTestProjectsFileName = TPManagement.GetCurrentTestProjectFileName();
            objMarsTestingFrame.RunTestBatchFileByThread(strCurrentTestTestProjectsFileName, ((App)Application.Current).currentStartMode);
            this.Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(delegate() { this.WindowState = WindowState.Minimized; }));
        }

        



        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Regex regex = new Regex(@"\d{1}");
            Match match = regex.Match("[StorageMode:Comparing;ColIndx:2;ConvertMethod:NONE];TRADE_PAY_INDEX");
            if (match.Success)
            {
                Console.WriteLine(match.Value);
            }
            string strReg = "";// TxtReg.Text;
            regex = new Regex(strReg);//new Regex(@"(>|<|=|>=|<=){1}(\d+)\?return\=(true|false):(\S+)\[(\S+)\]");
            match = regex.Match("RowCount>=0?return=false:clickButton[dd,d]");
            string[] arrSt = regex.Split("RowCount>=0?return=false:clickButton[dd,d]");
            if (match.Success)
            {
                Console.WriteLine(match.Value);
            }
        }

/*
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            string strFullPath = Assembly.GetExecutingAssembly().Location;
            string strPrntDir = Directory.GetParent(Directory.GetParent(strFullPath).FullName).FullName;
            MessageBox.Show(strPrntDir);
        }
        */
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            /** Load List Table to Combox **/
            List<string> lstTestProjects = null;
            try
            {
                lstTestProjects = TPManagement.GetTestProjects();
            }
            catch (Exception err)
            {
                this.Dispatcher.BeginInvoke(DispatcherPriority.Background,
                    new Action(delegate()
                {
                    MessageBox.Show(string.Format("Can't load Test project Files, Exceptions:[{0}]", err.Message));
                }));

                return;
            }

            AvailableProjects.Items.Clear();

            foreach (string strItem in lstTestProjects)
            {
                AvailableProjects.Items.Add(strItem);
            }
            int iIdx = AvailableProjects.Items.IndexOf(TPManagement.CNST_DEFAULT_TESTPROJECTNAME);
            AvailableProjects.SelectedIndex = iIdx >= 0 ? iIdx : 0;

            /** Load applications **/
            LoadRegisterdApps();

            /** Load CheckBox **/
            LoadCheckBoxInfo();
        }

        private void LoadCheckBoxInfo()
        {
            string strBase = AppConfigReader.GetBaseLineMode();
            if (string.IsNullOrEmpty(strBase))
            {
                this.BaseLineCheckBox.IsChecked = true;
                return;
            }

            this.BaseLineCheckBox.IsChecked = AppConfigReader.IsBaseLineMode();
        }

        private void LoadRegisterdApps()
        {
            this.AvailableApps.Items.Clear();
            AvailableApps.Tag = null;

            ConfigTestApplicationCollection lstApps = AppConfigReader.GetRegApplications();
            foreach (ConfigTestApplication objTestApp in lstApps)
            {
                AvailableApps.Items.Add(objTestApp.AppName);                
            }
            string strDefaultName = AppConfigReader.GetDefaultApplicationNameEx();
            int iIdx = AvailableApps.Items.IndexOf(strDefaultName);
            AvailableApps.Tag = lstApps;
            AvailableApps.SelectedIndex = iIdx >= 0 ? iIdx : (AvailableApps.Items.Count>=0?0:-1);
        }

        private int SwitchAddinsVersion()
        {
            if (AvailableApps.Tag == null) return 1;
            /** **/
            int iIdx = AvailableApps.SelectedIndex;
            if (iIdx < 0) return 1;
            ConfigTestApplicationCollection lstApps = (ConfigTestApplicationCollection)AvailableApps.Tag;
            if (iIdx >= lstApps.Count) return 1;
            ConfigTestApplication objTestApp = lstApps[iIdx];
            string strErrorInfo = "";
            int iError = TargetApplicationsManagement.SwitchAddinsFiles(objTestApp.ExtraRequirement,ref strErrorInfo);
            if (iError != 1)
            {
                this.Dispatcher.BeginInvoke(DispatcherPriority.Background,
                    new Action(delegate()
                    {
                        MessageBox.Show(string.Format(@"Can't switch to sepecial Swfconfig file :[{0}], with ErrorInfo:[{1}]", objTestApp.ExtraRequirement, strErrorInfo));
                    }));
            }
            return iError;            
        }

        private int SwitchSwfConfig()
        {
            if (AvailableApps.Tag == null) return 1;

            int iIdx = AvailableApps.SelectedIndex;
            if (iIdx < 0) return 1;
            ConfigTestApplicationCollection lstApps = (ConfigTestApplicationCollection)AvailableApps.Tag;
            if (iIdx >= lstApps.Count) return 1;
            ConfigTestApplication objTestApp = lstApps[iIdx];
            int iError = TargetApplicationsManagement.SwitchSwfConfigFile(objTestApp.ExtraRequirement);
            if (iError!=1)
            {
                this.Dispatcher.BeginInvoke(DispatcherPriority.Background,
                    new Action(delegate()
                    {
                        MessageBox.Show(string.Format("Can't switch to sepecial Swfconfig file:[{0}]", objTestApp.ExtraRequirement));
                    }));
            }
            return 1;
        }

        private void StopServiceButton_Click(object sender, RoutedEventArgs e)
        {
            /** Kill Monitor **/
            string[] cnst_arrApps = { "QtpStarter", "TestFrameMonitor" };
            foreach (string strAppName in cnst_arrApps)
            {
                TigerMarsUtil.KillProcessByName(strAppName);
            }
            /** Stop services**/
            if (objMarsTestingFrame == null) return;
            objMarsTestingFrame.StopService();
        }

        private void BaseLineCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            /** write baseLine Information into configuration file **/
            if (objMarsTestingFrame == null) return;
            objMarsTestingFrame.ChangeBaseLineValue(this.BaseLineCheckBox.IsChecked.Value);
            
        }

        private void AvailableApps_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (objMarsTestingFrame == null) return;
            objMarsTestingFrame.ChangeDefaultApplication(this.AvailableApps.SelectedItem.ToString());
        }


    }
}

