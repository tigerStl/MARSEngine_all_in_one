﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;

namespace TestFrameStarter.TestProjects
{
    /** Test Project Management */
    class TPManagement
    {
        public const string CNST_APPSETTING_CURRENT_PROJECT_FILENAME = "CurrentTestProjectsFileName";
        public const string CNST_DEFAULT_TESTPROJECTNAME = "Batch";
        private const string CONNECTION_STRING = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=<FILENAME>;Extended Properties=\"Excel 8.0;HDR=Yes;MaxScanRows=1;IMEX=1;\";";

        private const string cnst_default_projectfilename = "qtpBatch.xls";

        public static string AppRootDir = null;
        public static string CurrentTestProjectName = null;

        private static List<string> TestProjectNames = null;

        private static void GetAppRootDir()
        {
            string strDir = Path.GetDirectoryName(typeof(TPManagement).Assembly.Location);
            strDir = Directory.GetParent(strDir).FullName;
            AppRootDir = strDir;
            if (!Directory.Exists(AppRootDir))
                Directory.CreateDirectory(AppRootDir);
        }

        private static void GetCurrentProjectFileName()
        {
            if (CurrentTestProjectName == null)
            {
                CurrentTestProjectName = ConfigurationManager.AppSettings[CNST_APPSETTING_CURRENT_PROJECT_FILENAME];
                if (string.IsNullOrEmpty(CurrentTestProjectName))
                    CurrentTestProjectName = cnst_default_projectfilename;
            }
        }

        public static string GetCurrentTestProjectFileName()
        {
            GetCurrentProjectFileName() ;
            if (AppRootDir == null) GetAppRootDir();
            return string.Format(@"{0}\Dash Board\{1}",AppRootDir, CurrentTestProjectName );
        }

        public static List<string> GetTestProjects()
        {
            if (TestProjectNames == null)
            {
                string strFullPath = GetCurrentTestProjectFileName();
                string strOleDBCnn = CONNECTION_STRING.Replace("<FILENAME>", strFullPath);
                using (OleDbConnection objCnn = new OleDbConnection(strOleDBCnn))
                {
                    objCnn.Open();
                    TestProjectNames = new List<string>();
                    DataTable dtSchema = objCnn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    for (int i = 0; i < dtSchema.Rows.Count; i++)
                    {
                        TestProjectNames.Add(dtSchema.Rows[i]["TABLE_NAME"].ToString().Replace("$",""));
                    }
                    objCnn.Close();
                }
            }

            return TestProjectNames;    

        }

    }
}
