﻿using com.Mars.Constants;
using MarsTestFrame.SourceCode.systemUtil;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;


/**
 * Record:
 *   Date  : 07/31/2015
 *   Reason: for server mode, services can start without starting qtp at the same time
 * 
 * */

namespace TestFrameStarter
{

    
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private FrameWorkStartMode CurrentStartMode = FrameWorkStartMode.FWSM_Normal;

        public FrameWorkStartMode currentStartMode { get { return this.CurrentStartMode; } }

        public ILicenseMgr gLicenseMgr { get; set; }

        protected override void OnStartup(StartupEventArgs e)
        {
            //MessageBox.Show(string.Format("{0}",e.Args.Length));
            try
            {
                if (e.Args.Length < 1)
                {
                    gLicenseMgr = TestFrameLicense.LoadLicense();
                    return;
                }
                if ("-S".CompareTo(e.Args[0])==0)
                {
                    /** just services **/
                    CurrentStartMode |= FrameWorkStartMode.FWSM_Slience;
                    gLicenseMgr = TestFrameLicense.LoadLicense();
                }
                if ("-GL".CompareTo(e.Args[0])==0)
                {
                    /** generate lisence file **/
                    if (e.Args.Length < 2)
                    {
                        Console.WriteLine("-GL [Date-YYYYMMDD] [Hard DiskNumber]");
                        Application.Current.Shutdown();
                    }
                    TestFrameLicense.Save(e.Args[1], e.Args.Length<=2?null:e.Args[2]);
                    TestFrameLicense.LoadLicense();
                    
                    Application.Current.Shutdown();
                }

               
            }
            finally
            {
                base.OnStartup(e);
            }
            
        }
    }
}
