﻿using com.Mars.Constants;
using MarsTestFrame.com.Mars.TestConfigObjects;
using MarsTestFrame.SourceCode.com.Mars.Excels.ConfigurationXls;
using MarsTestFrame.SourceCode.com.Mars.TCDataSource;
using MarsTestFrame.SourceCode.com.Mars.KeyWords;
using Route2NSEx.src.Marquis.systemUtil;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;
using MarsTestFrame.SourceCode.com.Mars.KeyWords.KeyWordObject;
using com.Mars.TestFrame.Application;
using MarsTestFrame.SourceCode.systemUtil;
using MarsTestFrame.SourceCode.com.Mars.Compiler;
using System.Data.OleDb;

namespace MarsTestFrame.CommuniteServer
{
    #region events begin
    public delegate int CompilerCurrentTestCaseEvent(string strCurrentTestSuiteName, string strCurrentTestCaseName);



    #endregion //events begin
    [ServiceBehavior(ConcurrencyMode=ConcurrencyMode.Reentrant)]
    public class MarsTestFrameCommuniteServer : IMarsTigerFrameWorkService
    {

        #region Logger
        private static MLogger Logger = MLogger.GetLogger(typeof(MarsTestFrameCommuniteServer));
        #endregion

        #region Member
        private int miCurrentStepId = 0;
        private List<ConfigObjectBase> mlstSteps = null;
        private ERROR_CODE meCde_LastError;
        private ServiceHost mobjHost = null;
        private int miCurrentLoopCnt = -1;
        /** Get current Data File **/
        private TCObjects mobjCurrentTestSuite = null;
        private int miCurrentTestCaseId = -1;
        private string mstrCurrrentApplicationShortName="";
        #endregion //Member

        #region current testcase compiler error information
        private string mstrCurrentErrorInformation;
        private TestStep mobjCurrentErrorStep;
        private int miCurrentErrorId;        
        #endregion //current testcase compiler error information

        #region properties
        public string CurrentTestCaseName { get { return mobjCurrentTestSuite == null ? "" : (mobjCurrentTestSuite.CurrentRunName == null ? "" : mobjCurrentTestSuite.CurrentRunName); } }
        public string CurrentTestSuiteName { get { return mobjCurrentTestSuite == null ? "" : (mobjCurrentTestSuite.XlsFileNameWithPath == null ? "" : mobjCurrentTestSuite.XlsFileNameWithPath); } }
        public int CurrentLoopCount { get { return this.miCurrentLoopCnt; } set { this.miCurrentLoopCnt = value; } }
        public int CurrentTestCaseId { get { return this.miCurrentTestCaseId; } set { this.miCurrentTestCaseId = value; } }
        public string CurrentTestApplicationShortName { get{return this.mstrCurrrentApplicationShortName ;} set {this.mstrCurrrentApplicationShortName = value ;}} 
        #endregion

        #region version 1.1
        //private string mstrCurrentTestSuiteAction;        
        #endregion //version 1.1

        #region event

        protected CompilerCurrentTestCaseEvent CompilerTestCaseEventHandler = null;
        protected int AgentCompilerTestCaseEventHandler(string strTestSuite, string strTestCase)
        {
            if (CompilerTestCaseEventHandler == null)
            {
                Logger.Error("AgentCompilerTestCaseEventHandler", string.Format(ERROR_INFO.GET_ERROR_STR(ERROR_CODE._SERVICE_ERROR_NO_COMPILER_ASSIGNED_PARA_2), strTestSuite, strTestCase));
                return (int)ERROR_CODE._SERVICE_ERROR_NO_COMPILER_ASSIGNED_PARA_2;
            }
            return this.CompilerTestCaseEventHandler(strTestSuite, strTestCase);
        }
        public void AddCompilerTestCaseEventHandler(CompilerCurrentTestCaseEvent funcPointer, bool isAdd)
        {
            if (isAdd) this.CompilerTestCaseEventHandler += funcPointer;
            else this.CompilerTestCaseEventHandler -= funcPointer;
        }

        protected OnGetCurrentTestCaseByTestSuiteAndTestCaseNameEvent GetCurrentTestCaseByTestSuiteAndTestCaseNameEventHandler = null;
        public void AddGetCurrentTestCaseByTSAndTCEventHandler(OnGetCurrentTestCaseByTestSuiteAndTestCaseNameEvent funcGet, bool isAdd)
        {
            if (isAdd)
                this.GetCurrentTestCaseByTestSuiteAndTestCaseNameEventHandler = funcGet;
            else
                this.GetCurrentTestCaseByTestSuiteAndTestCaseNameEventHandler = null;
        }
        protected ERROR_CODE AgentGetCurrentTCByTSAndTCNameEventHandlerImpl(string strTestSuiteName, string strTestCaseName, TCObjects objTarget)
        {
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            if (this.GetCurrentTestCaseByTestSuiteAndTestCaseNameEventHandler == null)
            {
                eCde = ERROR_CODE._SERVICE_ERROR_NO_TESTCASE_GETTER_ASSIGNED_PARA_0;
                Logger.Error("AgentGetCurrentTCByTSAndTCNameEventHandlerImpl", ERROR_INFO.GET_ERROR_STR(eCde));
                return eCde;
            }

            return eCde = this.GetCurrentTestCaseByTestSuiteAndTestCaseNameEventHandler(strTestSuiteName, strTestCaseName, objTarget);
        }

        protected OnCompileListEvent CompileListEventHandler = null;
        public void AddOnCompileListEventHandler(OnCompileListEvent funcCompile, bool isAdd)
        {
            if (isAdd)
                this.CompileListEventHandler = funcCompile;
            else
                this.CompileListEventHandler = null;
        }
        //(List<ConfigObjectBase> lstSteps, ref int iErrorStep, ref TestStep objErrorStep, ref string strErrorInfo,string strCurrentAppShortName = null, string strCurrentPegObj = null , bool isSubMode = false,
        //OnCompileOneStepEvent funcCompileOneEventImpl=null, AfterCompileOneStepEvent funcAfterCompileEventImpl=null) ;
        protected ERROR_CODE AgentOnCompileListEventImpl(List<ConfigObjectBase> lstSteps, ref int iErrorStep, ref TestStep objErrorStep, ref string strErrorInfo, string strCurrentAppShortName = null, string strCurrentPegObj = null, bool isSubMode = false,
            OnCompileOneStepEvent funcCompileOneEventImpl = null, AfterCompileOneStepEvent funcAfterCompileEventImpl = null)
        {
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            if (this.CompileListEventHandler == null)
            {
                return eCde;
            }
            eCde = this.CompileListEventHandler(lstSteps, ref iErrorStep, ref objErrorStep, ref strErrorInfo, strCurrentAppShortName, strCurrentPegObj, isSubMode, funcCompileOneEventImpl, funcAfterCompileEventImpl);
            if (eCde != ERROR_CODE._NO_ERROR)
            {
                Logger.Error("AgentOnCompileListEventImpl", string.Format("Can't Compile Steps, Error Step Info:\r\n\tId is:{0}, \r\n\tKeyword:[{1}], \r\n\tObject:{2}",
                    objErrorStep.RunID, objErrorStep.Keyword, objErrorStep.ObjectName));
                return eCde;
            }
            return eCde;
        }

        protected OnBeginNavigateTestSuite onBeginNavigateTestSuiteHandler = null;
        public void AddOnNavigateHandler(OnBeginNavigateTestSuite funcOnNavigate, bool isAdd)
        {
            if (isAdd)
                onBeginNavigateTestSuiteHandler += funcOnNavigate;
            else
                onBeginNavigateTestSuiteHandler = null;
        }
        protected ERROR_CODE AgentOnNavigateTestSuiteEventImpl()
        {
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            if (this.onBeginNavigateTestSuiteHandler == null)
            {
                eCde = ERROR_CODE._SERVICE_ERROR_NO_TESTSUITE_NAVIGATE_ASSIGNED_PARA_0;
                Logger.Error("AgentOnNavigateTestSuiteEventImpl", ERROR_INFO.GET_ERROR_STR(eCde));
                return eCde;
            }
            
            eCde = this.onBeginNavigateTestSuiteHandler();
            if (eCde != ERROR_CODE._NO_ERROR)
            {
                Logger.Error("AgentOnNavigateTestSuiteEventImpl", string.Format("Can't Begin Navigate Test suite, error number is {0:x}", eCde));
                return eCde;
            }
            return eCde;
        }

        protected OnBeginNavigateTestSuiteWithRelyIdAndLoopId onBeginNavigateTestSuiteWithRelyIdAndLoopIdHandler = null;
        public void AddOnBeginNavigateTestSuiteWithRelyIdAndLoopIdHandler(OnBeginNavigateTestSuiteWithRelyIdAndLoopId funcOnNavigate, bool isAdd)
        {
            if (isAdd)
                onBeginNavigateTestSuiteWithRelyIdAndLoopIdHandler += funcOnNavigate;
            else
                onBeginNavigateTestSuiteWithRelyIdAndLoopIdHandler = null;
        }
        protected ERROR_CODE AgentonBeginNavigateTestSuiteWithRelyIdAndLoopIdImpl(string strRelyId, int iLoop)
        {
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            if (this.onBeginNavigateTestSuiteWithRelyIdAndLoopIdHandler == null)
            {
                eCde = ERROR_CODE._SERVICE_ERROR_NO_TESTSUITE_NAVIGATE_ASSIGNED_PARA_0;
                Logger.Error("AgentonBeginNavigateTestSuiteWithRelyIdAndLoopIdImpl", ERROR_INFO.GET_ERROR_STR(eCde));
                return eCde;
            }

            eCde = this.onBeginNavigateTestSuiteWithRelyIdAndLoopIdHandler(strRelyId, iLoop);
            if (eCde != ERROR_CODE._NO_ERROR)
            {
                Logger.Error("AgentonBeginNavigateTestSuiteWithRelyIdAndLoopIdImpl", string.Format("Can't Begin Navigate Test suite, error number is {0:x}", eCde));
                return eCde;
            }
            return eCde;
        }

        protected OnGetNextTestSuiteEvent onGetNextTestSuiteEventHandler = null;
        public void AddOnGetNextTestSuiteEvent(OnGetNextTestSuiteEvent funcOnNextTS, bool isAdd)
        {
            if (isAdd)
                this.onGetNextTestSuiteEventHandler += funcOnNextTS;
            else
                this.onGetNextTestSuiteEventHandler = null;
        }
        protected ERROR_CODE AgentOnGetNextTestSuiteEventImpl()
        {
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            if (this.onGetNextTestSuiteEventHandler == null)
            {
                eCde = ERROR_CODE._SERVICE_ERROR_NO_GETNEXTTESTSUITE_ASSIGNED_PARA_0;
                Logger.Error("AgentOnGetNextTestSuiteEventImpl", ERROR_INFO.GET_ERROR_STR(eCde));
                return eCde;
            }
            this.mobjCurrentTestSuite = new TCObjects();
            eCde = this.onGetNextTestSuiteEventHandler(ref this.mobjCurrentTestSuite);
            if (eCde != ERROR_CODE._NO_ERROR)
            {
                Logger.Error("AgentOnGetNextTestSuiteEventImpl", string.Format("Can't Get Next test suite with error number is [{0:x}]", eCde));
                return eCde;
            }
            /*** to load all information of the current testsuite ***/
            eCde = this.AgentOnAfterLoadCurrentTestSuiteEventImpl();
            
            return eCde;
        }

        protected OnLoadCurrrentTestSuitEvent onAfterGetTestSuiteEventHandler = null;
        public void AddOnLoadcurrentTestSuiteEvent(OnLoadCurrrentTestSuitEvent funcM, bool isAdd)
        {
            if (isAdd)
                this.onAfterGetTestSuiteEventHandler += funcM;
            else
                this.onAfterGetTestSuiteEventHandler = null;
        }

        protected ERROR_CODE AgentOnAfterLoadCurrentTestSuiteEventImpl()
        {
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            if (this.onAfterGetTestSuiteEventHandler == null)
            {
                eCde = ERROR_CODE._SERVICE_ERROR_NO_GETNEXTTESTSUITE_ASSIGNED_PARA_0;
                Logger.Error("AgentOnAfterLoadCurrentTestSuiteEventImpl", ERROR_INFO.GET_ERROR_STR(eCde));
                return eCde;
            }
            eCde = this.onAfterGetTestSuiteEventHandler();
            if (eCde != ERROR_CODE._NO_ERROR)
            {
                Logger.Error("AgentOnAfterLoadCurrentTestSuiteEventImpl", string.Format("Can't initialize Test suite with error number:[{0}]", eCde));
                return eCde;
            }
            return eCde;
        }

        protected OnTestsuiteIsDoneEvent onTestSuiteIsDoneEventHandler = null;
        public void AddOnTestSuiteIsDoneEventHandler(OnTestsuiteIsDoneEvent funcHandler, bool isAdd)
        {
            if (isAdd)
                this.onTestSuiteIsDoneEventHandler += funcHandler;
            else
                this.onTestSuiteIsDoneEventHandler = null;
        }
        protected ERROR_CODE AgentOnTestSuiteIsDoneEventImpl(TestSuiteRunStatusInfo objStatus, bool isContinueWhenFalse)
        {
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            if (this.onTestSuiteIsDoneEventHandler == null)
            {
                eCde = ERROR_CODE._SERVCIE_ERROR_NO_TESTSUITE_IS_DONE_STATUS_ASSIGNED_PARA_0;
                Logger.Error("AgentOnTestSuiteIsDoneEventImpl", ERROR_INFO.GET_ERROR_STR(eCde));
                return eCde;
            }

            eCde = this.onTestSuiteIsDoneEventHandler(objStatus, this.mobjCurrentTestSuite.Action4Project, isContinueWhenFalse);
            if (eCde != ERROR_CODE._NO_ERROR)
            {
                Logger.Error("AgentOnTestSuiteIsDoneEventImpl", string.Format(string.Format("Can't write status to Project running file:[{0}], error Number:[{1:x}]", objStatus, eCde)));
                return eCde;
            }
            return eCde;
        }

        #endregion //event


        #region service functions
        public string GetCurrentTestSuiteId4Project()
        {
            return this.mobjCurrentTestSuite == null ? null : this.mobjCurrentTestSuite.Id4Project;
        }

        public string GetApplicationExtraInfo(string strApplicationShortName, ref int iErrorId)
        {
            TargetApplicationInfo objData = TargetApplicationsManagement.GetRegApplicationByStepValue(strApplicationShortName);
            if (objData == null)
            {
                iErrorId = (int)ERROR_CODE._SERVICE_ERROR_NO_APPLICATION_INFO_PARA_1;
                return SystemConstant.CNST_APPCONFIG_APPREG_ATTR_EXTRA_DEFAULT;
            }
            return string.IsNullOrEmpty(objData.ExtraRequirement) ? SystemConstant.CNST_APPCONFIG_APPREG_ATTR_EXTRA_DEFAULT : objData.ExtraRequirement; 
        }

        public string GetCurrentApplicationCmd()
        {
            int iError = (int)ERROR_CODE._NO_ERROR ;
            string strResult = GetApplicationFullCmdByShortName(this.mstrCurrrentApplicationShortName, ref iError) ;
            if (iError!=(int)ERROR_CODE._NO_ERROR)
            {
                return null ;
            }
            if (string.IsNullOrEmpty(strResult))
            {
                Logger.Error("GetCurrentApplicationCmd", string.Format("Can't get current Application:[{0}]", this.CurrentTestApplicationShortName)) ;
                return null ;
            }
            return strResult ;
        }

        public int GetExtraPopupMenuCount()
        {
            try
            {
                TargetApplicationInfo objData = TargetApplicationsManagement.GetRegApplicationByStepValue(CurrentTestApplicationShortName);
                if (objData==null) return 1 ;
                
                return int.Parse(objData.ExtraPopupMenuCount);
            }
            catch
            {
                return 1 ;//default value 
            }
        }
           
        public  string GetCurrentDefaultTestApplication()
        {
            return AppConfigReader.GetDefaultApplicationName();
        }

        public string GetBaseLineMode()
        {
            string strMode = AppConfigReader.GetBaseLineMode();
            strMode = strMode ?? "";
            if (!((SystemConstant.CNST_APPCONFIG_APPSETTING_BASELINEMODE_BUILD.ToUpper().CompareTo(strMode.ToUpper()) == 0)
            || (SystemConstant.CNST_APPCONFIG_APPSETTING_BASELINEMODE_COMPARE.ToUpper().CompareTo(strMode.ToUpper()) == 0)))
            {
                // default value setting
                Logger.Warnning("GetBaseLineMode",
                    string.Format("Value of BaseLine is not a value expected, default value will be used. \r\nOnly [{0}/{1}] can be accepted."
                    , SystemConstant.CNST_APPCONFIG_APPSETTING_BASELINEMODE_BUILD, SystemConstant.CNST_APPCONFIG_APPSETTING_BASELINEMODE_COMPARE));
                strMode = SystemConstant.CNST_APPCONFIG_APPSETTING_BASELINEMODE_BUILD;
            }
            return strMode;
        }

        public int GetNextTestSuite()
        {
            ERROR_CODE eCde = this.AgentOnGetNextTestSuiteEventImpl();
            return (int)eCde;
        }

        public int NotifyCurrentTestSuiteRunStatus(TestSuiteRunStatusInfo objStatus,bool isContinueWhenFalse)
        {
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            eCde = this.AgentOnTestSuiteIsDoneEventImpl(objStatus, isContinueWhenFalse);
            return (int)eCde;
        }

        public string GetCurrentTestCaseName()
        {
            return CurrentTestCaseName;
        }

        public string GetCurrentTestSuiteName()
        {
            return CurrentTestSuiteName;
        }

        public int GetCurrentStepRunType(string strKeyWordName)
        {
            Keyword_RunType eRunType = KeyWordObjectInfo.GetKeywordRunType(strKeyWordName);
            return (int)eRunType;
        }

        public int GetTestLoopCount()
        {
            if (miCurrentLoopCnt < 0)
            {
                if (mobjCurrentTestSuite == null)
                {
                    Logger.Info("GetTestLoopCount", "Test suite object is null. ");
                    return -1;
                }
                miCurrentLoopCnt = mobjCurrentTestSuite.GetTestLoopCount();
            }
            return miCurrentLoopCnt;
        }

        public MarsTestFrameCommuniteServer()
        {
            Logger.logBegin("MarsTestFrameCommuniteServer");
            Logger.logEnd("MarsTestFrameCommuniteServer");
        }

        private void InitializeData()
        {
            miCurrentStepId = 0;
            meCde_LastError = ERROR_CODE._NO_ERROR;
        }
        #endregion 

        #region Test Suite Navigate
        public int BeginNavigateTestSuite()
        {
            Logger.logBegin("BeginNavigateTestSuite");
            int iError = (int)AgentOnNavigateTestSuiteEventImpl();
            Logger.logEnd("BeginNavigateTestSuite");
            return iError;
        }

        public int BeginNavigateTestSuiteWithRelyIdAndLoop(string strRelyId, int iLoop)
        {
            Logger.logBegin("BeginNavigateTestSuite");
            Logger.Info("BeginNavigateTestSuite", string.Format("Parameters- strRelyId:[{0}], iLoop:[{1}]", strRelyId, iLoop)) ;
            int iError = (int)AgentonBeginNavigateTestSuiteWithRelyIdAndLoopIdImpl(strRelyId, iLoop);
            Logger.logEnd("BeginNavigateTestSuite");
            return iError;
        }
        #endregion //Test Suite Navigate

        #region Test Step Navigate
        public bool StartTestStepNavigate()
        {
            try
            {
                Logger.logBegin("StartTestStepNavigate");
                InitializeData();
                return mlstSteps != null;
            }
            finally
            {
                Logger.logEnd("StartTestStepNavigate");
            }
        }

        public bool GetNextTestCase()
        {
            Logger.logBegin("GetNextTestCase");
            Logger.logEnd("GetNextTestCase");
            return true;
        }

        public List<SubTestInfo4Services> GetCurrentSubActionsInfo(ref int iCde)
        {
            Logger.logBegin("GetCurrentSubActionsInfo");
            //ERROR_CODE eCde = ERROR_CODE._NO_ERROR;

            //if (this.)

            Logger.logEnd("GetCurrentSubActionsInfo");
            return null;
        }

        public TestStep4Services GetNextTestStep()
        {
            Logger.logBegin("GetNextTestStep");
            try
            {
                if (miCurrentStepId < mlstSteps.Count)
                {
                    ConfigObjectBase objBase = mlstSteps[miCurrentStepId];
                    if (!(objBase is TestStep))
                    {
                        this.meCde_LastError = ERROR_CODE._SERVICE_ERROR_OBJECT_TYPE_IS_NOT_TEST_STEP;
                        Logger.Error("GetNextTestStep", string.Format(ERROR_INFO.GET_ERROR_STR(this.meCde_LastError), objBase.GetType().ToString()));
                        return null;
                    }
                    miCurrentStepId++;
                    Logger.Info("GetNextTestStep", string.Format("Current StepId:[{0}]", miCurrentStepId));
                    /** convert to from TestStep to  **/
                    TestStep4Services objStep4Service = new TestStep4Services();
                    TestStep objStep = (TestStep)objBase;
                    objStep.CloneToService(objStep4Service);
                    //objStep4Service.CloneFromStep(objStep);
                    this.meCde_LastError = ERROR_CODE._NO_ERROR;
                    return objStep4Service;
                }
                else
                {
                    this.meCde_LastError = ERROR_CODE._NO_ERROR;
                    return null;
                }

            }
            finally
            {
                Logger.logEnd("GetNextTestStep");
            }
        }
        #endregion //Test step navigate

        public string GetApplicationFullCmdByShortName(string strShortName, ref int eCde)
        {
            Logger.logBegin("GetApplicationFullCmdByShortName");
            try
            {
                TargetApplicationInfo objData = TargetApplicationsManagement.GetRegApplicationByStepValue(strShortName);
                if (objData == null)
                {
                    eCde = (int)ERROR_CODE._SERVICE_ERROR_NO_APPLICATION_INFO_PARA_1;
                    return null;
                }
                eCde = (int)ERROR_CODE._NO_ERROR;
                return objData.Path;
            }
            catch (Exception e)
            {
                if (e is MarsExceptions)
                {
                    eCde = ((MarsExceptions)e).ErrorId;
                }
                else
                {
                    eCde = (int)ERROR_CODE._SERVICE_ERROR_NO_APPLICATION_INFO_PARA_1;
                    Logger.Error("GetApplicationFullCmdByShortName", string.Format(ERROR_INFO.GET_ERROR_STR((ERROR_CODE)eCde), strShortName));
                }
            }
            Logger.logEnd("GetApplicationFullCmdByShortName");
            return null;
        }

        public void EndTestStepNavigate()
        {
            Logger.logBegin("EndTestStepNavigate");
            InitializeData();
            Logger.logEnd("EndTestStepNavigate");
        }

        public ERROR_CODE GetLastError()
        {
            return meCde_LastError;
        }

        public void InitListTestSteps(List<ConfigObjectBase> lstData)
        {
            Logger.logBegin("SetListTestSteps");
            InitializeData();
            mlstSteps = this.mobjCurrentTestSuite.CurrentStepsList;
            Logger.logEnd("SetListTestSteps");
        }

        public List<TestStep4Services> GetCurrentCompiledList(ref int eCde)
        {
            Logger.logBegin("GetCurrentCompiledList");
            eCde = (int)ERROR_CODE._NO_ERROR;
            List<TestStep4Services> lstResult = new List<TestStep4Services>();
            
            foreach (ConfigObjectBase objBase in mlstSteps)
            {
                if (!(objBase is TestStep))
                {
                    eCde = (int)ERROR_CODE._SERVICE_ERROR_OBJECT_TYPE_IS_NOT_TEST_STEP;
                    Logger.Error("GetNextTestStep", string.Format(ERROR_INFO.GET_ERROR_STR(this.meCde_LastError), objBase.GetType().ToString()));
                    return null;
                }
                TestStep objStp = (TestStep)objBase;
                TestStep4Services objTarget = new TestStep4Services();
                objStp.CloneToService(objTarget);
                lstResult.Add(objTarget);
            }
            Logger.Info("GetCurrentCompiledList", string.Format("Total Compiled list item count:[{0}]", lstResult.Count));

            return lstResult;
        }

#if _Datafrom_Database
        /// <summary>
        /// Test Case ID is necessary for Database mode, as it is the database key for 
        /// </summary>
        /// <param name="iTestCaseIde"></param>
        /// <param name="objErrorObj"></param>
        /// <param name="iErrorId"></param>
        /// <param name="strError"></param>
        /// <returns></returns>
        public int CompilerCurrentTestCaseById(int iTestCaseIde, ref TestStep4Services objErrorObj, ref int iErrorId, ref string strError)
        {
            Logger.logBegin("CompilerCurrentTestCaseById");
            Logger.logEnd("CompilerCurrentTestCaseById");
            return (int)ERROR_CODE._NO_ERROR;
        }
#endif

        public int CompilerCurrentTestCase(string strSuiteName, string strCaseName,ref TestStep4Services objErrorObj, ref int iErrorRunId, ref string strError)
        {
            /** 
             * NOT Finished perfect yet, 
             * The perfect flow is listed below:
             * 1, check the currrent suitename or caseName equals strSuiteName or strCaseName
             *      1.1 return error when either of them desn't match
             * 2, Get the lst from test project
             * 3, compiler and return ErrorInformation
             * **/
            Logger.logBegin("CompilerCurrentTestCase");
            TCObjects objTC = mobjCurrentTestSuite;//new TCObjects();
            ERROR_CODE eCde = this.AgentGetCurrentTCByTSAndTCNameEventHandlerImpl(strSuiteName, strCaseName, objTC);
            if (eCde != ERROR_CODE._NO_ERROR)
            {
                Logger.logBegin("CompilerCurrentTestCase No Agent....");
                return (int)eCde;
            }
            //mobjCurrentTestSuite = objTC;
            eCde = objTC.loadXlsFile();
            if (eCde != ERROR_CODE._NO_ERROR)
            {
                Logger.Error("CompilerCurrentTestCase", string.Format("Error Code ocurrs after call objTestSuit.loadXlsFile() ERROR_CODE:[{0:X}]，ERROR_INFO:[{1}]", eCde, ERROR_INFO.GET_ERROR_STR(eCde)));
                return (int)eCde;
            }
            /*** 加载数据 ***/
            objTC.InitDefaultDataFileName();
            eCde = objTC.loadData();
            int iErrorStep = -1;
            TestStep objErrorTestStep = new TestStep();
            string strErrorInfo = "";
            eCde = this.AgentOnCompileListEventImpl(objTC.CurrentStepsList, ref iErrorStep, ref objErrorTestStep, ref strErrorInfo, null, null, false, null, null);
            if (eCde != ERROR_CODE._NO_ERROR)
            {
                if (iErrorStep<0)
                {
                    /** Error Code with minus **/
                    iErrorRunId = iErrorStep;
                    objErrorObj = null;
                    strError = strErrorInfo;
                }
                else
                {
                    iErrorRunId = iErrorStep;
                    if (objErrorTestStep!=null)
                        objErrorTestStep.CloneToService(objErrorObj);
                    strError = strErrorInfo;
                }
                return (int)eCde;
            }
            else
            {
                this.mlstSteps = objTC.CurrentStepsList;
            }
            return (int)ERROR_CODE._NO_ERROR;
        }
        /*
        public ERROR_CODE StopService()
        {
            Logger.logBegin("StopService");
            try
            {
                if (this.mobjHost == null) return ERROR_CODE._NO_ERROR;
                this.mobjHost.Close();
            }
            catch (Exception e)
            {
                ERROR_CODE eCde = ERROR_CODE._SERVICE_ERROR_NO_SERVICE_STOP_UNKNOW;
                Logger.Error("StopService", string.Format(ERROR_INFO.GET_ERROR_STR(eCde), e.Message));
                return eCde;

            }
            Logger.logEnd("StopService");
            return ERROR_CODE._NO_ERROR;
        }
         * */

        public void StopService(ref string strErrorINfo)
        {
            strErrorINfo=null ;
            if (this.mobjHost == null) return;
            if (this.mobjHost.State != CommunicationState.Opened) return;
            try
            {
                this.mobjHost.Close();
            }
            catch (Exception e)
            {
                Logger.Error("StopService", strErrorINfo = string.Format("Can't stop the services, Exception:[{0}]", e.Message), e);
                return ;
            }

            
        }

        public ERROR_CODE StartService(string strURL)
        {
            Logger.logBegin("StartService");

            try
            {
                Uri objURL = new Uri(strURL);
                this.mobjHost = new ServiceHost(this, objURL);
                var behaviour = mobjHost.Description.Behaviors.Find<ServiceBehaviorAttribute>();

                behaviour.InstanceContextMode = InstanceContextMode.Single;
                behaviour.ConcurrencyMode = ConcurrencyMode.Multiple;

                ServiceMetadataBehavior smb = mobjHost.Description.Behaviors.Find<ServiceMetadataBehavior>();
                if (smb == null)
                    smb = new ServiceMetadataBehavior();
                //smb.HttpGetEnabled = true;

                //smb.HttpGetBinding 
                smb.MetadataExporter.PolicyVersion = PolicyVersion.Policy15;
                this.mobjHost.Description.Behaviors.Add(smb);
                
                this.mobjHost.AddServiceEndpoint(typeof(IMarsTigerFrameWorkService), new NetTcpBinding(), "");
                this.mobjHost.Open();                
                return ERROR_CODE._NO_ERROR;
            }
            catch (Exception e)
            {
                ERROR_CODE eCde = ERROR_CODE._SERVICE_ERROR_NO_SERVICE_START_UNKNOW;
                Logger.Error("StartService", string.Format(ERROR_INFO.GET_ERROR_STR(eCde), e.Message), e);
                return eCde;
            }
            finally
            {
                Logger.logEnd("StartService");
            }
        }

        public int OnGetNextTestSuite()
        {
            miCurrentLoopCnt = -1 ;
            int iResult = (int)AgentOnGetNextTestSuiteEventImpl();
            if (iResult != (int)ERROR_CODE._NO_ERROR)
            {
                return iResult;
            }
            if (this.mobjCurrentTestSuite == null)
                return -1;
            
            InitListTestSteps(this.mobjCurrentTestSuite.CurrentStepsList);
            //SetCurrentErrorInfo(iErrorStep, strCurrentError, objErrorStep);
            return iResult;
        }

        #region Data File service
        public string GetDataStringFromDataFile(string strObjectName, int iLoopId, ref int eCde)
        {
            Logger.logBegin("GetDataStringFromDataFile");

            if (this.mobjCurrentTestSuite == null)
            {
                eCde = (int)ERROR_CODE._SERVICE_ERROR_SERVER_NO_TESTSUITE_SETTING;
                Logger.Error("GetDataStringFromDataFile", ERROR_INFO.GET_ERROR_STR((ERROR_CODE)eCde));
                return null;
            }
            ERROR_CODE eCdeTmp = ERROR_CODE._NO_ERROR;
            string strData = this.mobjCurrentTestSuite.GetDataStringFromDataFile(strObjectName, iLoopId, ref eCdeTmp);
            eCde = (int)eCdeTmp;

            Logger.logEnd("GetDataStringFromDataFile");
            return strData;
        }

        public bool IsDataSetSet2Skipped(int iLoopID)
        {
            Logger.logBegin("IsDataSetSet2Skipped");
            int eCde;
            if (this.mobjCurrentTestSuite == null)
            {
                eCde = (int)ERROR_CODE._SERVICE_ERROR_SERVER_NO_TESTSUITE_SETTING;
                Logger.Error("GetDataStringFromDataFile", ERROR_INFO.GET_ERROR_STR((ERROR_CODE)eCde));
                return false;
            }

            bool isSkip = this.mobjCurrentTestSuite.IsDataSetSet2Skipped(iLoopID);
            Logger.Info("IsDataSetSet2Skipped", string.Format("returns [{0}]", isSkip));
            Logger.logEnd("IsDataSetSet2Skipped");
            return isSkip;
        }

        public int StoreDataBack(string strObjectNameIdx, string strData2Store, int iLoop)
        {
            Logger.logBegin("StoreDataBack");
            int eCde;
            if (this.mobjCurrentTestSuite == null)
            {
                eCde = (int)ERROR_CODE._SERVICE_ERROR_SERVER_NO_TESTSUITE_SETTING;
                Logger.Error("GetDataStringFromDataFile", ERROR_INFO.GET_ERROR_STR((ERROR_CODE)eCde));
                return eCde;
            }
            ERROR_CODE eCdeTmp = this.mobjCurrentTestSuite.SaveDataToSpecialCell(strObjectNameIdx, iLoop, strData2Store);
            if (eCdeTmp==ERROR_CODE._NO_ERROR)
            {
                /**Create externel infor storing orignal data**/
                string strBaseInfo= this.GetBaseLineMode();
                if (SystemConstant.CNST_APPCONFIG_APPSETTING_BASELINEMODE_BUILD.CompareTo(strBaseInfo)==0)
                {
                }
                
            }

            Logger.logEnd("StoreDataBack");
            return (int)eCdeTmp;
        }

        
        public int CompareGuiDataByLoopId(string strLoopId)
        {
            return (int)ERROR_CODE._NO_ERROR;
        }

        #endregion //Data File service


        internal void SetCurrentTestSuiteObject(TCObjects objTestSuit)
        {
            mobjCurrentTestSuite = objTestSuit;
        }

        public int SwitchDataFile(string strDataFileName)
        {
            Logger.logBegin("SwitchDataFile");
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            eCde = this.mobjCurrentTestSuite.SwitchCurrentDataFile(strDataFileName);
            Logger.logEnd("SwitchDataFile");
            return (int)eCde;
        }

        public int StoreDataBackComparisonMode(string strTestCaseName, string strValueWithSetting, string strValue, int iLoop, string strBaseLineMode, bool isComparison = false)
        {
            Logger.logBegin("StoreDataBackComparisonMode");
            ERROR_CODE eCde = ERROR_CODE._NO_ERROR;
            string strObjectNameIdx = "";
            strObjectNameIdx = this.mobjCurrentTestSuite.GetObjectNameFromComparisonMode(strValueWithSetting, ref eCde);
            if (eCde != ERROR_CODE._NO_ERROR) return (int)eCde;
            eCde = this.mobjCurrentTestSuite.SaveDataToSpecialCellComparisonMode(strObjectNameIdx, strValueWithSetting, strValue, iLoop);
            if (eCde != ERROR_CODE._NO_ERROR) return (int)eCde;
            
            Logger.logEnd("StoreDataBackComparisonMode");
            return (int)eCde;
        }


        private void SetCurrentErrorInfo(int iErrorStep, string strCurrentError, TestStep objErrorStep)
        {
            this.miCurrentErrorId = iErrorStep;
            this.mstrCurrentErrorInformation = strCurrentError;
            this.mobjCurrentErrorStep = objErrorStep;
        }

        internal void ChangeBaseLineMode(string strBaseLineMode)
        {
            AppConfigReader.SetAppSetting(SystemConstant.CNST_APPCONFIG_APPSETTING_BASELINEMODE, strBaseLineMode);
        }

        internal void ChangeDefaultApplication(string strDefaultApplication)
        {
            AppConfigReader.SetAppSetting(SystemConstant.CNST_APPCONFIG_APPSETTING_DEFAULTAPP, strDefaultApplication);
        }
    }

}
