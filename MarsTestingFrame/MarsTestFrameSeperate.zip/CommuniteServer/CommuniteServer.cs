﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;

using com.Mars.Constants;
using System.ServiceModel.Description;
using System.IO;

namespace MarsTestFrame.CommuniteServer
{
    [DataContract]
    public class TestSuiteRunStatusInfo
    {
        [DataMember]
        public string RunResult;//true or false
        [DataMember]
        public string CauseReason;//true or false
        [DataMember]
        public string StartTime;//true or false
        [DataMember]
        public string EndTime;//true or false
    }
    
    [DataContract]
    public class TestStep4Services
    {
        #region properties
        [DataMember]
        public int RunID;
        [DataMember]
        public string ObjectName;
        [DataMember]
        public string Keyword ;
        [DataMember]
        public string Row_Column;
        [DataMember]
        public string Value;
        [DataMember]
        public string QuickAccess;
        [DataMember]
        public string Comment;
        [DataMember]
        public int Loop=-1;

        [DataMember]
        public SubTestInfo4Services SubTestInfo;
        #endregion
    }

    public interface IMarsTestNotificationCallback
    {
        [OperationContract]
        void OnPreCompile(string strTestSuite, string strTestCase);
        [OperationContract]
        void OnConnected();
        [OperationContract]
        void OnGetData(string strObjectName,string strData,string strError);
        [OperationContract]
        void OnPreCompileTestSteps(List<TestStep4Services> lstSteps);

//#region Selector
//        [OperationContract]
//        void OnGetSelector(Stream objSelectorStreamForDeserialized) ;
//#endregion //Selector
    }

    [ServiceContract(CallbackContract = typeof(IMarsTestNotificationCallback))]
    public interface IMarsTigerFrameWorkService
    {
        [OperationContract]
        string GetCurrentTestSuiteId4Project();
        [OperationContract]
        bool StartTestStepNavigate();
        [OperationContract]
        TestStep4Services GetNextTestStep();
        [OperationContract]
        void EndTestStepNavigate();
        [OperationContract]
        ERROR_CODE GetLastError() ;
        [OperationContract]
        int GetTestLoopCount();
        [OperationContract]
        string GetCurrentTestCaseName();
        [OperationContract]
        string GetCurrentTestSuiteName();
        [OperationContract]
        string GetDataStringFromDataFile(string strObjectName, int iLoopId, ref int eCde);
        [OperationContract]
        int StoreDataBack(string strObjectNameIdx, string strData2Store, int iLoop);
        [OperationContract]
        int SwitchDataFile(string strDataFileName);
        [OperationContract]
        int StoreDataBackComparisonMode(string strTestCaseName, string strValueWithSetting, string strValue, int iLoop, string strBaseLineMode, bool isComparison);
        [OperationContract]
        int GetCurrentStepRunType(string strKeyWordName);
        [OperationContract]
        string GetApplicationFullCmdByShortName(string strShortName, ref int eCde);
        [OperationContract]
        List<TestStep4Services> GetCurrentCompiledList(ref int eCde);
        [OperationContract]
        int CompilerCurrentTestCase(string strSuiteName, string strCaseName, ref TestStep4Services objErrorObj, ref int iErrorId,ref string strError);
#if _Datafrom_Database
        [OperationContract]
        int CompilerCurrentTestCaseById(int iTestCaseIde, ref TestStep4Services objErrorObj, ref int iErrorId, ref string strError);
#endif
        [OperationContract]
        int BeginNavigateTestSuite();
        [OperationContract]
        int BeginNavigateTestSuiteWithRelyIdAndLoop(string strRelyId, int iLoop);
        [OperationContract]
        int OnGetNextTestSuite();
        [OperationContract]
        int NotifyCurrentTestSuiteRunStatus(TestSuiteRunStatusInfo objStatus, bool isContinueWhenFalse);
        [OperationContract]
        string GetBaseLineMode();
        [OperationContract]
        int CompareGuiDataByLoopId(string strLoopId);
        [OperationContract]
        string GetCurrentDefaultTestApplication();
        [OperationContract]
        string GetApplicationExtraInfo(string strApplicationShortName, ref int iErrorId);
        [OperationContract]
        string GetCurrentApplicationCmd();
        [OperationContract]
        int GetExtraPopupMenuCount();

        //version 1.1
        [OperationContract]
        bool IsDataSetSet2Skipped(int iLoopId);


        //#region ObjectSelector
        //int GetSelector(string strObjectType)
        //#endregion //ObjectSelector
    }


    [DataContract]
    public class SubTestInfo4Services
    {
        [DataMember]
        public string keyword;
        [DataMember]
        public List<TestStep4Services> SubActions;

    }   

    [DataContract]
    public class IFSubItemInfo4Services
    {
        [DataMember]
        public string PropertyName;
        [DataMember]
        public string OperationMark;
        [DataMember]
        public string Value2Compare;
        [DataMember]
        public string AssociatedAction;
        [DataMember]
        public string ReturnValue;
        [DataMember]
        public string SubKeyword;
        [DataMember]
        public string SubObjectAndOthers;
    }    

    [DataContract]
    public class IFSubTestInfo4Services : SubTestInfo4Services
    {
        [DataMember]
        public List<IFSubItemInfo4Services> SubIFItems;
    }


}
