﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QtpStarter.MarsMsgCenter
{
    public class MarsDispatchCenter
    {

    }
}
