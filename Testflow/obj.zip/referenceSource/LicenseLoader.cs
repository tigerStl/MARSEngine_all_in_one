﻿using Route2NSEx.src.Marquis.systemUtil;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace MarsTestFrame.SourceCode.systemUtil
{
    public interface ILicenseMgr
    {
        bool isAvailable();
        string GetLicenseInfo();

    }
    [Serializable()]
    public class TestFrameLicense : ILicenseMgr
    {
        private static MLogger logger = MLogger.GetLogger(typeof(TestFrameLicense));

        public int mode { get; set; }
        private const string cnst_defaultFilename = "MarsTestFrame.lic";
        private int LicenseYearInfo = -0x4A; /**YEAR * 37 **/
        private int LicenseMonthInfo = -0x26;/**Month * 19 **/
        private int LicenseDateInfo = -0x86;/** day * 67 **/

        public bool isAvailable()
        {
            DateTime dt = DateTime.Now;
            DateTime objInfo = new DateTime(LicenseYearInfo / 0x25, LicenseMonthInfo / 0x13, LicenseDateInfo / 0x43);
            return objInfo >= dt;
        }

        public string GetLicenseInfo()
        {
            return null;
        }

        public static ILicenseMgr LoadLicense()
        {
            string strFilePath = GetFilePath();
            BinaryFormatter objBF = new BinaryFormatter();
            ILicenseMgr objIResult = null;
            try
            {
                string strLicReversted = "";

                FileStream objFS = File.Open(strFilePath, FileMode.Open);
                using (StreamReader objStremReader = new StreamReader(objFS))
                {
                    strLicReversted = objStremReader.ReadToEnd();
                }

                if ((strLicReversted.Length % 2) != 0) throw new Exception("Wrong License File!!");
                int iCnt = strLicReversted.Length / 2;
                byte[] arrFBRevsersted = new byte[iCnt];
                for (int i = 0; i < iCnt; i++)
                {
                    byte.TryParse(strLicReversted.Substring(i * 2, 2), NumberStyles.HexNumber, null, out arrFBRevsersted[iCnt - i - 1]);
                }

                MemoryStream objMemory = new MemoryStream(arrFBRevsersted);
                object objResult = objBF.Deserialize(objMemory);

                //object objResult = objBF.Deserialize(objFS);
                if (objResult is TestFrameLicense)
                {
                    objIResult = (TestFrameLicense)objResult;
                    return objIResult;
                }
                logger.Error("######", "no file find....");
                return new TestFrameLicense();
            }
            catch (Exception e)
            {
                logger.Error("######", string.Format("Exception :[{0}]", e.Message), e);
                return new TestFrameLicense();
            }
            finally
            {

            }


        }

        public static void Save(string strlastDate)
        {
            TestFrameLicense objResutl = new TestFrameLicense();
            string strYear = strlastDate.Substring(0, 4);
            string strMonth = strlastDate.Substring(4, 2);
            string strDte = strlastDate.Substring(6, 2);
            objResutl.LicenseYearInfo = int.Parse(strYear) * 37;
            objResutl.LicenseMonthInfo = int.Parse(strMonth) * 0x13;
            objResutl.LicenseDateInfo = int.Parse(strDte) * 67;

            MemoryStream ms = new MemoryStream();
            BinaryFormatter objBF = new BinaryFormatter();
            objBF.Serialize(ms, objResutl);

            StringBuilder sb = new StringBuilder();
            ms.Seek(0, SeekOrigin.Begin);
            byte[] arrData = ms.GetBuffer();
            byte[] arrDes = new byte[ms.Length];
            System.Buffer.BlockCopy(arrData, 0, arrDes, 0, arrDes.Length);
            string s = "";
            for (int i = 0; i < arrDes.Length; i++)
            {
                if (i == 0)
                {
                    s = string.Format("{0:X2}", arrDes[i]);
                }
                else
                {
                    s = string.Format("{1:X2}{0}", s, arrDes[i]);
                }
            }
            string strResult = s;
            //string strResult = Encoding.ASCII.GetString(arrData);
            //byte[] arrR = Encoding.ASCII.GetBytes(strResult) ;
            FileStream objFS = new FileStream("C:\\automationTest\\Automation Workbooks\\dlls\\" + cnst_defaultFilename, FileMode.Create);
            objFS.Seek(0, SeekOrigin.Begin);

            byte[] bytes = Encoding.ASCII.GetBytes(strResult);
            //System.Buffer.BlockCopy(strResult.ToCharArray(), 0, bytes, 0, bytes.Length);

            objFS.Write(bytes, 0, bytes.Length);
            objFS.Flush();
            objFS.Close();
            objFS = null;
            /*
            FileStream objFS = new FileStream("C:\\automationTest\\Automation Workbooks\\" + cnst_defaultFilename,FileMode.CreateNew);
            BinaryFormatter objBF = new BinaryFormatter();
            objBF.Serialize(objFS, objResutl);
            objBF = null;
            objFS.Flush();
             
            objFS = null;
             * * */
        }

        private static string GetFilePath()
        {
            string stmp = Assembly.GetExecutingAssembly().Location;

            stmp = string.Format("{0}\\{1}", stmp.Substring(0, stmp.LastIndexOf('\\')), cnst_defaultFilename);
            return stmp;
        }
    }

    internal class LicenseLoader
    {

    }
}
