﻿using com.Mars.Constants;
using MarsTestFrame.SourceCode.systemUtil;
using Route2NSEx.src.Marquis.systemUtil;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace TestFlowClient.Mars.TigerConfig
{
    internal class AppConfigReader
    {
        private static MLogger Logger = MLogger.GetLogger(typeof(AppConfigReader));
        private static Configuration gCurrentConfiguration = null;
        private static Configuration GetConfigurationInstance()
        {
            if (gCurrentConfiguration == null)
            {
                string exeConfigPath = typeof(AppConfigReader).Assembly.Location;
                gCurrentConfiguration = ConfigurationManager.OpenExeConfiguration(exeConfigPath);
                
            }
            return gCurrentConfiguration;
        }

        private static NameValueCollection ConvertNameValueSectionToCollection(ConfigurationSection objSection, string strSectionName)
        {
            Logger.logBegin("ConvertNameValueSectionToCollection");

            try
            {
                if (objSection == null)
                {
                    Logger.Error("GetSpecialNodeValueFromNameValue", string.Format(ERROR_INFO.GET_ERROR_STR(ERROR_CODE._APP_NO_SECTION_SPECIAL) + ":[{0}]", strSectionName));
                    return null;
                }
                string strParamsSectionRawXml = objSection.SectionInformation.GetRawXml();
                XmlDocument objSectionXmlDoc = new XmlDocument();
                objSectionXmlDoc.Load(new StringReader(strParamsSectionRawXml));
                NameValueSectionHandler objHandler = new NameValueSectionHandler();

                NameValueCollection handlerCreatedCollection =
                    objHandler.Create(null, null, objSectionXmlDoc.DocumentElement) as NameValueCollection;
                return handlerCreatedCollection;
            }
            finally
            {
                Logger.logEnd("ConvertNameValueSectionToCollection");
            }


        }

        internal static string GetConfigServerMonitorURLInfo()
        {
            Configuration objConfig = GetConfigurationInstance();
            ConfigurationSection objSection = objConfig.GetSection(SystemConstant.CNST_APPCONFIG_SECTION_MONITORSERVICE);
            NameValueCollection lstKeyValues = ConvertNameValueSectionToCollection(objSection, SystemConstant.CNST_APPCONFIG_SECTION_MONITORSERVICE);
            string[] strProtocol = lstKeyValues.GetValues(SystemConstant.CNST_SERVICE_KEY_URL_PROTOCOL);
            if ((strProtocol == null) || (strProtocol.Length == 0))
            {
                throw new MarsExceptions((int)ERROR_CODE._SERVICE_ERROR_NO_PROTOCO_SETTING, ERROR_INFO.GET_ERROR_STR(ERROR_CODE._SERVICE_ERROR_NO_PROTOCO_SETTING));
            }
            string[] strHost = lstKeyValues.GetValues(SystemConstant.CNST_SERVICE_KEY_URL_HOST);
            if ((strHost == null) || (strHost.Length == 0))
            {
                throw new MarsExceptions((int)ERROR_CODE._SERVICE_ERROR_NO_HOST_SETTING, ERROR_INFO.GET_ERROR_STR(ERROR_CODE._SERVICE_ERROR_NO_HOST_SETTING));
            }
            string[] strPort = lstKeyValues.GetValues(SystemConstant.CNST_SERVICE_KEY_URL_PORT);
            if ((strPort == null) || (strPort.Length == 0))
            {
                throw new MarsExceptions((int)ERROR_CODE._SERVICE_ERROR_NO_PORT_SETTING, ERROR_INFO.GET_ERROR_STR(ERROR_CODE._SERVICE_ERROR_NO_PORT_SETTING));
            }
            string[] strServiceName = lstKeyValues.GetValues(SystemConstant.CNST_SERVICE_KEY_URL_SERVICENAME);
            if ((strServiceName == null) || (strServiceName.Length == 0))
            {
                throw new MarsExceptions((int)ERROR_CODE._SERVICE_ERROR_NO_SERVICENAME_SETTING, ERROR_INFO.GET_ERROR_STR(ERROR_CODE._SERVICE_ERROR_NO_SERVICENAME_SETTING));
            }
            string strResult = string.Format("{0}://{1}:{2}/{3}", strProtocol[0], strHost[0], strPort[0], strServiceName[0]);

            Logger.logEnd("GetConfigServerURLInfo");
            return strResult;
        }

        internal static string GetConfigServerURLInfo()
        {
            Logger.logBegin("GetConfigServerURLInfo");
            //ServicebasicInformation objServiceInfo = new ServicebasicInformation();
            Configuration objConfig = GetConfigurationInstance();
            ConfigurationSection objSection = objConfig.GetSection(SystemConstant.CNST_APPCONFIG_SECTION_FRAMEWORKSERVICE);
            NameValueCollection lstKeyValues = ConvertNameValueSectionToCollection(objSection, SystemConstant.CNST_APPCONFIG_SECTION_FRAMEWORKSERVICE);
            string[] strProtocol = lstKeyValues.GetValues(SystemConstant.CNST_SERVICE_KEY_URL_PROTOCOL);
            if ((strProtocol == null) || (strProtocol.Length == 0))
            {
                throw new MarsExceptions((int)ERROR_CODE._SERVICE_ERROR_NO_PROTOCO_SETTING, ERROR_INFO.GET_ERROR_STR(ERROR_CODE._SERVICE_ERROR_NO_PROTOCO_SETTING));
            }
            string[] strHost = lstKeyValues.GetValues(SystemConstant.CNST_SERVICE_KEY_URL_HOST);
            if ((strHost == null) || (strHost.Length == 0))
            {
                throw new MarsExceptions((int)ERROR_CODE._SERVICE_ERROR_NO_HOST_SETTING, ERROR_INFO.GET_ERROR_STR(ERROR_CODE._SERVICE_ERROR_NO_HOST_SETTING));
            }
            string[] strPort = lstKeyValues.GetValues(SystemConstant.CNST_SERVICE_KEY_URL_PORT);
            if ((strPort == null) || (strPort.Length == 0))
            {
                throw new MarsExceptions((int)ERROR_CODE._SERVICE_ERROR_NO_PORT_SETTING, ERROR_INFO.GET_ERROR_STR(ERROR_CODE._SERVICE_ERROR_NO_PORT_SETTING));
            }
            string[] strServiceName = lstKeyValues.GetValues(SystemConstant.CNST_SERVICE_KEY_URL_SERVICENAME);
            if ((strServiceName == null) || (strServiceName.Length == 0))
            {
                throw new MarsExceptions((int)ERROR_CODE._SERVICE_ERROR_NO_SERVICENAME_SETTING, ERROR_INFO.GET_ERROR_STR(ERROR_CODE._SERVICE_ERROR_NO_SERVICENAME_SETTING));
            }
            string strResult = string.Format("{0}://{1}:{2}/{3}", strProtocol[0], strHost[0], strPort[0], strServiceName[0]);

            Logger.logEnd("GetConfigServerURLInfo");
            return strResult;
        }
    }
}
