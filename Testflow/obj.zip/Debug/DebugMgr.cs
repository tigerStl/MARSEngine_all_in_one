﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TestFrameMonitor.Server.ServiceContracts;

namespace TestFlowClient.Debug
{
    public class DebugMgr
    {
        private List<TestFlowDebugInfo> BreakPointsList = new List<TestFlowDebugInfo>();
        public TestFlowDebugInfo currentDebuggerInfo { get; set; }

        public List<TestFlowDebugInfo> getBreakPointList()
        {
            return BreakPointsList;
        }


        internal void CleanDebuggerInfo4LoopChange()
        {
            BreakPointsList.Clear();
        }

        internal void CleanDebugerInfo4TSChange()
        {
            BreakPointsList.Clear();
        }
        internal void CleanDebugerInfo4DeubgerModeChange()
        {
            BreakPointsList.Clear();
        }

        internal void SortDebuggerList()
        {
            this.BreakPointsList.Sort(delegate(TestFlowDebugInfo x, TestFlowDebugInfo y) {
                if ((x == null) || (y == null)) return 0;                
                return x.CurrentFromId.CompareTo(y.CurrentFromId);
            });
        }
    }
}
